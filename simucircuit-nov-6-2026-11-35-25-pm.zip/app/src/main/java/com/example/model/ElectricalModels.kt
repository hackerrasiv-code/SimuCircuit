package com.example.model

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

enum class VoltageType {
  AC_L1, AC_L2, AC_L3, AC_N, PE,
  DC_POS, DC_NEG, SIGNAL
}

data class Pin(
  val id: String,
  val label: String,
  val voltageType: VoltageType,
  val componentId: String,
  val relativeOffset: Offset,
  val potentialVolts: Float = 0f,
  val isEnergized: Boolean = false,
  val description: String = ""
)

enum class WireColor(val displayName: String, val color: Color, val hex: String) {
  L1_BROWN("L1 (Brown)", WirePhase1Brown, "#8D6E63"),
  L2_BLACK("L2 (Black)", WirePhase2Black, "#37474F"),
  L3_GREY("L3 (Grey)", WirePhase3Grey, "#78909C"),
  N_BLUE("Neutral (Blue)", WireNeutralBlue, "#00B0FF"),
  PE_EARTH("Earth PE (Green/Yel)", WireEarthGround, "#76FF03"),
  DC_POS_RED("+24V DC (Red)", WireDcPositiveRed, "#E53935"),
  DC_NEG_BLUE("0V DC (Dark)", WireDcNegativeNavy, "#1E88E5"),
  CONTROL_PURPLE("Control (Purple)", WireControlPurple, "#AB47BC")
}

data class Wire(
  val id: String,
  val fromComponentId: String,
  val fromPinId: String,
  val toComponentId: String,
  val toPinId: String,
  val color: WireColor = WireColor.L1_BROWN,
  val isEnergized: Boolean = false,
  val currentAmps: Float = 0f,
  val isShortCircuit: Boolean = false
)

enum class ComponentCategory(val title: String) {
  POWER_SUPPLY("Power & Protection"),
  SWITCHING("Contactors & Relays"),
  ACTUATORS("Motors & Actuators"),
  CONTROLS("Switches & Buttons"),
  SENSORS("Industrial Sensors"),
  AUTOMATION("PLC & Logic")
}

enum class ComponentType(
  val category: ComponentCategory,
  val defaultTag: String,
  val defaultName: String
) {
  AC_SOURCE_3P(ComponentCategory.POWER_SUPPLY, "AC_PWR", "3-Phase 400V Supply"),
  SMPS_24V(ComponentCategory.POWER_SUPPLY, "PS1", "SMPS 24V DC 5A"),
  CIRCUIT_BREAKER_3P(ComponentCategory.POWER_SUPPLY, "Q1", "3-Pole Breaker (Motor)"),
  CIRCUIT_BREAKER_1P(ComponentCategory.POWER_SUPPLY, "Q2", "1-Pole Breaker (Control)"),
  MAGNETIC_CONTACTOR(ComponentCategory.SWITCHING, "KM1", "Magnetic Contactor"),
  THERMAL_OVERLOAD(ComponentCategory.SWITCHING, "FR1", "Thermal Overload Relay"),
  TIMER_RELAY(ComponentCategory.SWITCHING, "KT1", "On-Delay Timer Relay"),
  CONTROL_RELAY(ComponentCategory.SWITCHING, "K1", "8-Pin Control Relay"),
  MOTOR_3PHASE(ComponentCategory.ACTUATORS, "M1", "3-Phase Induction Motor"),
  PUSH_BUTTON_START(ComponentCategory.CONTROLS, "SB2", "Start Push Button (NO)"),
  PUSH_BUTTON_STOP(ComponentCategory.CONTROLS, "SB1", "Stop Push Button (NC)"),
  EMERGENCY_STOP(ComponentCategory.CONTROLS, "SB0", "Emergency Stop (NC)"),
  INDUCTIVE_SENSOR(ComponentCategory.SENSORS, "SQ1", "Inductive Proximity Sensor"),
  PHOTOELECTRIC_SENSOR(ComponentCategory.SENSORS, "SQ2", "Photoelectric Optical Sensor"),
  LIMIT_SWITCH(ComponentCategory.SENSORS, "SQ3", "Roller Limit Switch"),
  PILOT_LIGHT(ComponentCategory.ACTUATORS, "HL1", "Pilot Indicator Lamp"),
  INDUSTRIAL_BUZZER(ComponentCategory.ACTUATORS, "HA1", "Alarm Horn / Buzzer"),
  PLC_CONTROLLER(ComponentCategory.AUTOMATION, "PLC1", "Micro-PLC Controller")
}

data class CircuitComponent(
  val id: String,
  val type: ComponentType,
  val tag: String,
  val name: String,
  val x: Float,
  val y: Float,
  val width: Float = 140f,
  val height: Float = 160f,
  val isEnergized: Boolean = false,
  val isClosed: Boolean = false, // for switches / breakers / contactors
  val isTripped: Boolean = false, // for overload / breaker
  val timerElapsedSec: Float = 0f,
  val timerSetSec: Float = 5f,
  val motorRpm: Float = 0f,
  val motorMode: String = "OFF", // STAR, DELTA, FAULT, OFF
  val motorRotationCw: Boolean = true,
  val isShortCircuited: Boolean = false,
  val faultMessage: String? = null,
  val sensorActive: Boolean = false,
  val customParams: Map<String, String> = emptyMap(),
  val pins: List<Pin> = emptyList()
)

enum class SimulationState {
  STANDBY,
  RUNNING,
  SHORT_CIRCUIT_TRIPPED,
  OVERLOAD_TRIPPED
}

enum class LogLevel {
  INFO,
  SUCCESS,
  WARN,
  FAULT
}

data class DiagnosticLog(
  val id: Long = System.currentTimeMillis(),
  val timestamp: String,
  val level: LogLevel,
  val tag: String,
  val message: String,
  val remedy: String? = null
)

data class TerminalMeasurement(
  val pinLabel: String,
  val componentTag: String,
  val voltageVac: Float,
  val voltageVdc: Float,
  val isConnectedToGround: Boolean,
  val isEnergized: Boolean,
  val statusNote: String
)
