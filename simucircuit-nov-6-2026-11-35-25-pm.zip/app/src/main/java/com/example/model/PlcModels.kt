package com.example.model

enum class PlcInstructionType(val symbol: String, val displayName: String) {
  CONTACT_NO("[ ]", "Normally Open Contact"),
  CONTACT_NC("[/]", "Normally Closed Contact"),
  COIL_NORMAL("( )", "Output Coil"),
  COIL_SET("(S)", "Set Latch Coil"),
  COIL_RESET("(R)", "Reset Coil"),
  TIMER_ON_DELAY("[TON]", "On-Delay Timer")
}

data class PlcInstruction(
  val id: String,
  val type: PlcInstructionType,
  val operand: String, // e.g. "I0.0", "I0.1", "Q0.0", "M0.0", "T1"
  val presetSeconds: Float = 3.0f,
  val elapsedSeconds: Float = 0f,
  val isEnergized: Boolean = false
)

data class PlcLadderRung(
  val id: String,
  val rungNumber: Int,
  val comment: String = "",
  val instructions: List<PlcInstruction> = emptyList(),
  val outputInstruction: PlcInstruction? = null,
  val isRungActive: Boolean = false
)

data class PlcProgram(
  val rungs: List<PlcLadderRung> = emptyList(),
  val internalMarkers: Map<String, Boolean> = emptyMap(), // M0.0, M0.1
  val timers: Map<String, Float> = emptyMap() // T1 elapsed
)
