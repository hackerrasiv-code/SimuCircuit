package com.example.model

data class DiagnosticIssue(
  val title: String,
  val description: String,
  val severity: String, // "CRITICAL", "WARNING", "NOTE"
  val recommendation: String
)

data class TroubleshootingReport(
  val id: String = "RPT-${System.currentTimeMillis() % 100000}",
  val scenarioName: String,
  val technicianName: String = "Technician",
  val timestamp: String,
  val durationSeconds: Long,
  val isSuccessful: Boolean,
  val totalWiresConnected: Int,
  val totalComponentsActive: Int,
  val scorePercent: Int,
  val detectedIssues: List<DiagnosticIssue>,
  val sequenceHistory: List<String>
) {
  fun generateFormattedSummary(): String {
    val statusText = if (isSuccessful) "PASSED [CIRCUIT FULLY FUNCTIONAL]" else "FAILED [FAULTS DETECTED]"
    val minutes = durationSeconds / 60
    val seconds = durationSeconds % 60
    val timeFormatted = String.format("%02d:%02d", minutes, seconds)

    val issuesText = if (detectedIssues.isEmpty()) {
      "  None. Circuit integrity verified with zero wiring hazards."
    } else {
      detectedIssues.joinToString("\n") { issue ->
        "  - [${issue.severity}] ${issue.title}\n    Detail: ${issue.description}\n    Action: ${issue.recommendation}"
      }
    }

    val sequenceText = sequenceHistory.joinToString("\n") { "  > $it" }

    return """
=====================================================
      SIMUCIRCUIT - INDUSTRIAL INSPECTION REPORT
=====================================================
Report ID       : $id
Scenario        : $scenarioName
Date/Time       : $timestamp
Elapsed Time    : $timeFormatted
Result Status   : $statusText
Integrity Score : $scorePercent%

SYSTEM METRICS:
  Connected Wires      : $totalWiresConnected
  Active Components    : $totalComponentsActive

DIAGNOSTIC FAULT AUDIT:
$issuesText

EVENT LOG TRACE:
$sequenceText

RECOMMENDED TECHNICIAN ACTIONS:
${if (isSuccessful) "  Circuit ready for physical commissioning. All interlocking & protection verified." else "  Review schematic interlocks and terminal continuity before reapplying power."}
=====================================================
Generated offline by SimuCircuit Industrial Suite.
    """.trimIndent()
  }
}
