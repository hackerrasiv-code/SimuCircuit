package com.example.scenarios

import androidx.compose.ui.geometry.Offset
import com.example.model.*

object ComponentFactory {

  fun createComponent(
    type: ComponentType,
    id: String,
    tag: String,
    x: Float,
    y: Float,
    customParams: Map<String, String> = emptyMap()
  ): CircuitComponent {
    val pins = createPinsForType(type, id)
    val (w, h) = when (type) {
      ComponentType.AC_SOURCE_3P -> Pair(160f, 130f)
      ComponentType.SMPS_24V -> Pair(150f, 160f)
      ComponentType.CIRCUIT_BREAKER_3P -> Pair(150f, 160f)
      ComponentType.CIRCUIT_BREAKER_1P -> Pair(100f, 150f)
      ComponentType.MAGNETIC_CONTACTOR -> Pair(170f, 210f)
      ComponentType.THERMAL_OVERLOAD -> Pair(160f, 180f)
      ComponentType.TIMER_RELAY -> Pair(150f, 190f)
      ComponentType.CONTROL_RELAY -> Pair(140f, 180f)
      ComponentType.MOTOR_3PHASE -> Pair(200f, 220f)
      ComponentType.PUSH_BUTTON_START, ComponentType.PUSH_BUTTON_STOP, ComponentType.EMERGENCY_STOP -> Pair(110f, 130f)
      ComponentType.INDUCTIVE_SENSOR, ComponentType.PHOTOELECTRIC_SENSOR -> Pair(130f, 140f)
      ComponentType.LIMIT_SWITCH -> Pair(120f, 130f)
      ComponentType.PILOT_LIGHT, ComponentType.INDUSTRIAL_BUZZER -> Pair(100f, 120f)
      ComponentType.PLC_CONTROLLER -> Pair(240f, 220f)
    }

    return CircuitComponent(
      id = id,
      type = type,
      tag = tag,
      name = type.defaultName,
      x = x,
      y = y,
      width = w,
      height = h,
      isClosed = (type == ComponentType.CIRCUIT_BREAKER_3P || type == ComponentType.CIRCUIT_BREAKER_1P),
      pins = pins,
      customParams = customParams
    )
  }

  fun createPinsForType(type: ComponentType, compId: String): List<Pin> {
    return when (type) {
      ComponentType.AC_SOURCE_3P -> listOf(
        Pin("L1", "L1", VoltageType.AC_L1, compId, Offset(24f, 110f), 230f, true, "400V Phase 1 (Brown)"),
        Pin("L2", "L2", VoltageType.AC_L2, compId, Offset(56f, 110f), 230f, true, "400V Phase 2 (Black)"),
        Pin("L3", "L3", VoltageType.AC_L3, compId, Offset(88f, 110f), 230f, true, "400V Phase 3 (Grey)"),
        Pin("N", "N", VoltageType.AC_N, compId, Offset(120f, 110f), 0f, false, "Neutral Reference 0V (Blue)"),
        Pin("PE", "PE", VoltageType.PE, compId, Offset(144f, 110f), 0f, false, "Protective Earth Ground")
      )
      ComponentType.SMPS_24V -> listOf(
        Pin("L", "L", VoltageType.AC_L1, compId, Offset(26f, 20f), 0f, false, "AC Mains Line 230V"),
        Pin("N", "N", VoltageType.AC_N, compId, Offset(60f, 20f), 0f, false, "AC Mains Neutral 0V"),
        Pin("PE", "PE", VoltageType.PE, compId, Offset(94f, 20f), 0f, false, "Chassis Ground PE"),
        Pin("+24V", "+24V", VoltageType.DC_POS, compId, Offset(40f, 140f), 0f, false, "Regulated +24V DC Out"),
        Pin("0V", "0V", VoltageType.DC_NEG, compId, Offset(110f, 140f), 0f, false, "DC Return Common 0V")
      )
      ComponentType.CIRCUIT_BREAKER_3P -> listOf(
        Pin("1/L1", "1/L1", VoltageType.AC_L1, compId, Offset(30f, 20f), 0f, false, "Line 1 In"),
        Pin("3/L2", "3/L2", VoltageType.AC_L2, compId, Offset(75f, 20f), 0f, false, "Line 2 In"),
        Pin("5/L3", "5/L3", VoltageType.AC_L3, compId, Offset(120f, 20f), 0f, false, "Line 3 In"),
        Pin("2/T1", "2/T1", VoltageType.AC_L1, compId, Offset(30f, 140f), 0f, false, "Load 1 Out"),
        Pin("4/T2", "4/T2", VoltageType.AC_L2, compId, Offset(75f, 140f), 0f, false, "Load 2 Out"),
        Pin("6/T3", "6/T3", VoltageType.AC_L3, compId, Offset(120f, 140f), 0f, false, "Load 3 Out")
      )
      ComponentType.CIRCUIT_BREAKER_1P -> listOf(
        Pin("1/L", "1/L", VoltageType.AC_L1, compId, Offset(50f, 20f), 0f, false, "Control Line In"),
        Pin("2/T", "2/T", VoltageType.AC_L1, compId, Offset(50f, 130f), 0f, false, "Protected Control Line Out")
      )
      ComponentType.MAGNETIC_CONTACTOR -> listOf(
        Pin("1/L1", "1/L1", VoltageType.AC_L1, compId, Offset(26f, 20f), 0f, false, "Main Pole 1 In"),
        Pin("3/L2", "3/L2", VoltageType.AC_L2, compId, Offset(58f, 20f), 0f, false, "Main Pole 2 In"),
        Pin("5/L3", "5/L3", VoltageType.AC_L3, compId, Offset(90f, 20f), 0f, false, "Main Pole 3 In"),
        Pin("13", "13", VoltageType.SIGNAL, compId, Offset(122f, 20f), 0f, false, "Auxiliary NO In"),
        Pin("21", "21", VoltageType.SIGNAL, compId, Offset(150f, 20f), 0f, false, "Auxiliary NC In (Interlock)"),
        Pin("A1", "A1", VoltageType.SIGNAL, compId, Offset(26f, 105f), 0f, false, "Coil Terminal (+)"),
        Pin("A2", "A2", VoltageType.SIGNAL, compId, Offset(150f, 105f), 0f, false, "Coil Return (-)"),
        Pin("2/T1", "2/T1", VoltageType.AC_L1, compId, Offset(26f, 190f), 0f, false, "Main Pole 1 Out"),
        Pin("4/T2", "4/T2", VoltageType.AC_L2, compId, Offset(58f, 190f), 0f, false, "Main Pole 2 Out"),
        Pin("6/T3", "6/T3", VoltageType.AC_L3, compId, Offset(90f, 190f), 0f, false, "Main Pole 3 Out"),
        Pin("14", "14", VoltageType.SIGNAL, compId, Offset(122f, 190f), 0f, false, "Auxiliary NO Out (Latch)"),
        Pin("22", "22", VoltageType.SIGNAL, compId, Offset(150f, 190f), 0f, false, "Auxiliary NC Out")
      )
      ComponentType.THERMAL_OVERLOAD -> listOf(
        Pin("1/L1", "1/L1", VoltageType.AC_L1, compId, Offset(30f, 20f), 0f, false, "Through In 1"),
        Pin("3/L2", "3/L2", VoltageType.AC_L2, compId, Offset(75f, 20f), 0f, false, "Through In 2"),
        Pin("5/L3", "5/L3", VoltageType.AC_L3, compId, Offset(120f, 20f), 0f, false, "Through In 3"),
        Pin("2/T1", "2/T1", VoltageType.AC_L1, compId, Offset(30f, 160f), 0f, false, "Motor Out 1"),
        Pin("4/T2", "4/T2", VoltageType.AC_L2, compId, Offset(75f, 160f), 0f, false, "Motor Out 2"),
        Pin("6/T3", "6/T3", VoltageType.AC_L3, compId, Offset(120f, 160f), 0f, false, "Motor Out 3"),
        Pin("95", "95", VoltageType.SIGNAL, compId, Offset(24f, 100f), 0f, false, "NC Trip Contact In"),
        Pin("96", "96", VoltageType.SIGNAL, compId, Offset(56f, 100f), 0f, false, "NC Trip Contact Out"),
        Pin("97", "97", VoltageType.SIGNAL, compId, Offset(104f, 100f), 0f, false, "NO Fault Alarm In"),
        Pin("98", "98", VoltageType.SIGNAL, compId, Offset(136f, 100f), 0f, false, "NO Fault Alarm Out")
      )
      ComponentType.TIMER_RELAY -> listOf(
        Pin("A1", "A1", VoltageType.SIGNAL, compId, Offset(30f, 20f), 0f, false, "Timer Coil In (+)"),
        Pin("A2", "A2", VoltageType.SIGNAL, compId, Offset(120f, 20f), 0f, false, "Timer Coil Return (-)"),
        Pin("15", "15", VoltageType.SIGNAL, compId, Offset(30f, 170f), 0f, false, "Common Timed Contact"),
        Pin("18", "18", VoltageType.SIGNAL, compId, Offset(75f, 170f), 0f, false, "NO Timed Out (On-Delay)"),
        Pin("16", "16", VoltageType.SIGNAL, compId, Offset(120f, 170f), 0f, false, "NC Timed Out")
      )
      ComponentType.CONTROL_RELAY -> listOf(
        Pin("A1", "A1", VoltageType.SIGNAL, compId, Offset(30f, 20f), 0f, false, "Relay Coil A1 (+)"),
        Pin("A2", "A2", VoltageType.SIGNAL, compId, Offset(110f, 20f), 0f, false, "Relay Coil A2 (-)"),
        Pin("11", "11", VoltageType.SIGNAL, compId, Offset(25f, 160f), 0f, false, "Pole 1 Common"),
        Pin("14", "14", VoltageType.SIGNAL, compId, Offset(55f, 160f), 0f, false, "Pole 1 NO"),
        Pin("12", "12", VoltageType.SIGNAL, compId, Offset(85f, 160f), 0f, false, "Pole 1 NC"),
        Pin("21", "21", VoltageType.SIGNAL, compId, Offset(115f, 160f), 0f, false, "Pole 2 Common")
      )
      ComponentType.MOTOR_3PHASE -> listOf(
        Pin("U1", "U1", VoltageType.AC_L1, compId, Offset(35f, 30f), 0f, false, "Phase U1 In"),
        Pin("V1", "V1", VoltageType.AC_L2, compId, Offset(80f, 30f), 0f, false, "Phase V1 In"),
        Pin("W1", "W1", VoltageType.AC_L3, compId, Offset(125f, 30f), 0f, false, "Phase W1 In"),
        Pin("PE", "PE", VoltageType.PE, compId, Offset(170f, 30f), 0f, false, "Motor Frame Ground"),
        Pin("W2", "W2", VoltageType.SIGNAL, compId, Offset(35f, 190f), 0f, false, "Delta/Star Return W2"),
        Pin("U2", "U2", VoltageType.SIGNAL, compId, Offset(80f, 190f), 0f, false, "Delta/Star Return U2"),
        Pin("V2", "V2", VoltageType.SIGNAL, compId, Offset(125f, 190f), 0f, false, "Delta/Star Return V2")
      )
      ComponentType.PUSH_BUTTON_START -> listOf(
        Pin("13", "13", VoltageType.SIGNAL, compId, Offset(30f, 110f), 0f, false, "Start NO In"),
        Pin("14", "14", VoltageType.SIGNAL, compId, Offset(80f, 110f), 0f, false, "Start NO Out")
      )
      ComponentType.PUSH_BUTTON_STOP -> listOf(
        Pin("11", "11", VoltageType.SIGNAL, compId, Offset(30f, 110f), 0f, false, "Stop NC In"),
        Pin("12", "12", VoltageType.SIGNAL, compId, Offset(80f, 110f), 0f, false, "Stop NC Out")
      )
      ComponentType.EMERGENCY_STOP -> listOf(
        Pin("11", "11", VoltageType.SIGNAL, compId, Offset(30f, 110f), 0f, false, "E-Stop NC In"),
        Pin("12", "12", VoltageType.SIGNAL, compId, Offset(80f, 110f), 0f, false, "E-Stop NC Out")
      )
      ComponentType.INDUCTIVE_SENSOR, ComponentType.PHOTOELECTRIC_SENSOR -> listOf(
        Pin("+24V", "+24V", VoltageType.DC_POS, compId, Offset(25f, 120f), 0f, false, "Power +24V (Brown)"),
        Pin("0V", "0V", VoltageType.DC_NEG, compId, Offset(65f, 120f), 0f, false, "Common 0V (Blue)"),
        Pin("OUT", "OUT", VoltageType.SIGNAL, compId, Offset(105f, 120f), 0f, false, "PNP Signal Out (Black)")
      )
      ComponentType.LIMIT_SWITCH -> listOf(
        Pin("COM", "COM", VoltageType.SIGNAL, compId, Offset(25f, 110f), 0f, false, "Switch Common"),
        Pin("NO", "NO", VoltageType.SIGNAL, compId, Offset(60f, 110f), 0f, false, "Normally Open"),
        Pin("NC", "NC", VoltageType.SIGNAL, compId, Offset(95f, 110f), 0f, false, "Normally Closed")
      )
      ComponentType.PILOT_LIGHT, ComponentType.INDUSTRIAL_BUZZER -> listOf(
        Pin("X1", "X1", VoltageType.SIGNAL, compId, Offset(30f, 100f), 0f, false, "Signal/Phase In"),
        Pin("X2", "X2", VoltageType.SIGNAL, compId, Offset(70f, 100f), 0f, false, "Neutral/0V Return")
      )
      ComponentType.PLC_CONTROLLER -> listOf(
        Pin("L+", "L+", VoltageType.DC_POS, compId, Offset(25f, 20f), 0f, false, "PLC Power +24V DC"),
        Pin("M", "M", VoltageType.DC_NEG, compId, Offset(55f, 20f), 0f, false, "PLC Ground 0V DC"),
        Pin("I0.0", "I0.0", VoltageType.SIGNAL, compId, Offset(95f, 20f), 0f, false, "Digital Input 0 (Start)"),
        Pin("I0.1", "I0.1", VoltageType.SIGNAL, compId, Offset(130f, 20f), 0f, false, "Digital Input 1 (Stop)"),
        Pin("I0.2", "I0.2", VoltageType.SIGNAL, compId, Offset(165f, 20f), 0f, false, "Digital Input 2 (Sensor)"),
        Pin("I0.3", "I0.3", VoltageType.SIGNAL, compId, Offset(200f, 20f), 0f, false, "Digital Input 3 (Spare)"),
        Pin("1L", "1L", VoltageType.DC_POS, compId, Offset(35f, 200f), 0f, false, "Relay Common Feed"),
        Pin("Q0.0", "Q0.0", VoltageType.SIGNAL, compId, Offset(80f, 200f), 0f, false, "Digital Output 0 (Motor)"),
        Pin("Q0.1", "Q0.1", VoltageType.SIGNAL, compId, Offset(125f, 200f), 0f, false, "Digital Output 1 (Lamp)"),
        Pin("Q0.2", "Q0.2", VoltageType.SIGNAL, compId, Offset(165f, 200f), 0f, false, "Digital Output 2 (Buzzer)"),
        Pin("Q0.3", "Q0.3", VoltageType.SIGNAL, compId, Offset(205f, 200f), 0f, false, "Digital Output 3 (Spare)")
      )
    }
  }
}
