package com.example.scenarios

import com.example.model.*

data class CircuitScenario(
  val id: String,
  val title: String,
  val subtitle: String,
  val difficulty: String, // "Beginner", "Intermediate", "Advanced"
  val description: String,
  val objective: String,
  val components: List<CircuitComponent>,
  val initialWires: List<Wire>,
  val initialPlcProgram: PlcProgram = PlcProgram()
)

object ScenarioRepository {

  val scenarios: List<CircuitScenario> by lazy {
    listOf(
      createStarDeltaScenario(),
      createLatchingContactorScenario(),
      createSmpsAndSensorsScenario(),
      createPlcAutomationScenario(),
      createForwardReverseScenario(),
      createFreeformSandboxScenario()
    )
  }

  private fun createStarDeltaScenario(): CircuitScenario {
    val acPwr = ComponentFactory.createComponent(ComponentType.AC_SOURCE_3P, "pwr1", "AC400V", 40f, 40f)
    val q1 = ComponentFactory.createComponent(ComponentType.CIRCUIT_BREAKER_3P, "q1", "Q1", 240f, 40f)
    val q2 = ComponentFactory.createComponent(ComponentType.CIRCUIT_BREAKER_1P, "q2", "Q2", 420f, 40f)
    val km1 = ComponentFactory.createComponent(ComponentType.MAGNETIC_CONTACTOR, "km1", "KM1", 40f, 260f)
    val km2 = ComponentFactory.createComponent(ComponentType.MAGNETIC_CONTACTOR, "km2", "KM2 (Delta)", 240f, 260f)
    val km3 = ComponentFactory.createComponent(ComponentType.MAGNETIC_CONTACTOR, "km3", "KM3 (Star)", 440f, 260f)
    val kt1 = ComponentFactory.createComponent(ComponentType.TIMER_RELAY, "kt1", "KT1", 640f, 260f)
    val fr1 = ComponentFactory.createComponent(ComponentType.THERMAL_OVERLOAD, "fr1", "FR1", 40f, 520f)
    val motor = ComponentFactory.createComponent(ComponentType.MOTOR_3PHASE, "m1", "M1", 240f, 520f)
    val sb1 = ComponentFactory.createComponent(ComponentType.PUSH_BUTTON_STOP, "sb1", "STOP (SB1)", 480f, 520f)
    val sb2 = ComponentFactory.createComponent(ComponentType.PUSH_BUTTON_START, "sb2", "START (SB2)", 620f, 520f)

    // Pre-wired 3-phase and control connections
    val wires = mutableListOf(
      // AC Power -> Q1 3P Breaker
      Wire("w1", "pwr1", "L1", "q1", "1/L1", WireColor.L1_BROWN),
      Wire("w2", "pwr1", "L2", "q1", "3/L2", WireColor.L2_BLACK),
      Wire("w3", "pwr1", "L3", "q1", "5/L3", WireColor.L3_GREY),
      // AC Power -> Q2 1P Control Breaker
      Wire("w4", "pwr1", "L1", "q2", "1/L", WireColor.CONTROL_PURPLE),
      // Q1 -> KM1 Main Incomer
      Wire("w5", "q1", "2/T1", "km1", "1/L1", WireColor.L1_BROWN),
      Wire("w6", "q1", "4/T2", "km1", "3/L2", WireColor.L2_BLACK),
      Wire("w7", "q1", "6/T3", "km1", "5/L3", WireColor.L3_GREY),
      // KM1 Out -> Thermal Overload FR1 In
      Wire("w8", "km1", "2/T1", "fr1", "1/L1", WireColor.L1_BROWN),
      Wire("w9", "km1", "4/T2", "fr1", "3/L2", WireColor.L2_BLACK),
      Wire("w10", "km1", "6/T3", "fr1", "5/L3", WireColor.L3_GREY),
      // FR1 Out -> Motor U1, V1, W1
      Wire("w11", "fr1", "2/T1", "m1", "U1", WireColor.L1_BROWN),
      Wire("w12", "fr1", "4/T2", "m1", "V1", WireColor.L2_BLACK),
      Wire("w13", "fr1", "6/T3", "m1", "W1", WireColor.L3_GREY),
      // Motor Star Point (KM3 bridges U2, V2, W2)
      Wire("w14", "m1", "U2", "km3", "2/T1", WireColor.CONTROL_PURPLE),
      Wire("w15", "m1", "V2", "km3", "4/T2", WireColor.CONTROL_PURPLE),
      Wire("w16", "m1", "W2", "km3", "6/T3", WireColor.CONTROL_PURPLE),
      // Bridge KM3 top terminals for star short-ring
      Wire("w17", "km3", "1/L1", "km3", "3/L2", WireColor.CONTROL_PURPLE),
      Wire("w18", "km3", "3/L2", "km3", "5/L3", WireColor.CONTROL_PURPLE),
      // Delta KM2 connections: U1-W2, V1-U2, W1-V2
      Wire("w19", "km1", "2/T1", "km2", "1/L1", WireColor.L1_BROWN),
      Wire("w20", "km1", "4/T2", "km2", "3/L2", WireColor.L2_BLACK),
      Wire("w21", "km1", "6/T3", "km2", "5/L3", WireColor.L3_GREY),
      Wire("w22", "km2", "2/T1", "m1", "W2", WireColor.L1_BROWN),
      Wire("w23", "km2", "4/T2", "m1", "U2", WireColor.L2_BLACK),
      Wire("w24", "km2", "6/T3", "m1", "V2", WireColor.L3_GREY),
      // Control Circuit: Q2 out -> Stop PB -> Start PB -> KM1 A1
      Wire("w25", "q2", "2/T", "sb1", "11", WireColor.CONTROL_PURPLE),
      Wire("w26", "sb1", "12", "sb2", "13", WireColor.CONTROL_PURPLE),
      Wire("w27", "sb2", "14", "km1", "A1", WireColor.CONTROL_PURPLE),
      // Latch contact across Start PB (KM1 13-14)
      Wire("w28", "sb2", "13", "km1", "13", WireColor.CONTROL_PURPLE),
      Wire("w29", "sb2", "14", "km1", "14", WireColor.CONTROL_PURPLE),
      // KM1 Coil A2 to Neutral
      Wire("w30", "pwr1", "N", "km1", "A2", WireColor.N_BLUE),
      // Timer KT1 coil energized with KM1
      Wire("w31", "km1", "14", "kt1", "A1", WireColor.CONTROL_PURPLE),
      Wire("w32", "pwr1", "N", "kt1", "A2", WireColor.N_BLUE),
      // Star KM3 coil via Timer NC (15-16) and KM2 NC interlock (21-22)
      Wire("w33", "km1", "14", "kt1", "15", WireColor.CONTROL_PURPLE),
      Wire("w34", "kt1", "16", "km2", "21", WireColor.CONTROL_PURPLE),
      Wire("w35", "km2", "22", "km3", "A1", WireColor.CONTROL_PURPLE),
      Wire("w36", "pwr1", "N", "km3", "A2", WireColor.N_BLUE),
      // Delta KM2 coil via Timer NO (15-18) and KM3 NC interlock (21-22)
      Wire("w37", "kt1", "18", "km3", "21", WireColor.CONTROL_PURPLE),
      Wire("w38", "km3", "22", "km2", "A1", WireColor.CONTROL_PURPLE),
      Wire("w39", "pwr1", "N", "km2", "A2", WireColor.N_BLUE)
    )

    return CircuitScenario(
      id = "star_delta",
      title = "Star-Delta Motor Starter",
      subtitle = "Wye-Delta Starter with Timer & Contactor Interlocks",
      difficulty = "Advanced",
      description = "Full 3-Phase Star-Delta starter configuration. Starts the 3-phase induction motor with reduced voltage in Star mode (KM3 closed), then automatically transitions via Timer KT1 to Delta mode (KM2 closed) for full power. Demonstrates crucial NC contact electrical interlocks.",
      objective = "Turn ON breaker Q1 & Q2, press Start SB2, observe Star mode ramp to 1440 RPM, and after 5 seconds transition to Delta mode at 2920 RPM. Notice the electrical interlocks preventing cross-phase dead shorts.",
      components = listOf(acPwr, q1, q2, km1, km2, km3, kt1, fr1, motor, sb1, sb2),
      initialWires = wires
    )
  }

  private fun createLatchingContactorScenario(): CircuitScenario {
    val acPwr = ComponentFactory.createComponent(ComponentType.AC_SOURCE_3P, "pwr1", "AC400V", 40f, 40f)
    val q2 = ComponentFactory.createComponent(ComponentType.CIRCUIT_BREAKER_1P, "q2", "Q2 (Control)", 240f, 40f)
    val sb0 = ComponentFactory.createComponent(ComponentType.EMERGENCY_STOP, "sb0", "E-STOP", 380f, 40f)
    val sb1 = ComponentFactory.createComponent(ComponentType.PUSH_BUTTON_STOP, "sb1", "STOP", 520f, 40f)
    val sb2 = ComponentFactory.createComponent(ComponentType.PUSH_BUTTON_START, "sb2", "START", 660f, 40f)
    val km1 = ComponentFactory.createComponent(ComponentType.MAGNETIC_CONTACTOR, "km1", "KM1", 160f, 260f)
    val fr1 = ComponentFactory.createComponent(ComponentType.THERMAL_OVERLOAD, "fr1", "FR1", 380f, 260f)
    val hl1 = ComponentFactory.createComponent(ComponentType.PILOT_LIGHT, "hl1", "RUN (Green)", 580f, 260f)
    val hl2 = ComponentFactory.createComponent(ComponentType.PILOT_LIGHT, "hl2", "TRIP (Red)", 720f, 260f)

    val wires = mutableListOf(
      Wire("w1", "pwr1", "L1", "q2", "1/L", WireColor.L1_BROWN),
      Wire("w2", "q2", "2/T", "sb0", "11", WireColor.CONTROL_PURPLE),
      Wire("w3", "sb0", "12", "sb1", "11", WireColor.CONTROL_PURPLE),
      Wire("w4", "sb1", "12", "sb2", "13", WireColor.CONTROL_PURPLE),
      // Start PB out to Overload 95 NC
      Wire("w5", "sb2", "14", "fr1", "95", WireColor.CONTROL_PURPLE),
      // Overload 96 NC to KM1 Coil A1
      Wire("w6", "fr1", "96", "km1", "A1", WireColor.CONTROL_PURPLE),
      // Neutral to KM1 Coil A2
      Wire("w7", "pwr1", "N", "km1", "A2", WireColor.N_BLUE),
      // Holding (Latch) Contact: KM1 13-14 in parallel with Start SB2
      Wire("w8", "sb2", "13", "km1", "13", WireColor.CONTROL_PURPLE),
      Wire("w9", "sb2", "14", "km1", "14", WireColor.CONTROL_PURPLE),
      // Run Lamp HL1 across coil A1-A2
      Wire("w10", "km1", "A1", "hl1", "X1", WireColor.CONTROL_PURPLE),
      Wire("w11", "pwr1", "N", "hl1", "X2", WireColor.N_BLUE),
      // Trip Lamp HL2 fed from Q2 via Overload 97-98 NO
      Wire("w12", "q2", "2/T", "fr1", "97", WireColor.CONTROL_PURPLE),
      Wire("w13", "fr1", "98", "hl2", "X1", WireColor.CONTROL_PURPLE),
      Wire("w14", "pwr1", "N", "hl2", "X2", WireColor.N_BLUE)
    )

    return CircuitScenario(
      id = "latching_contactor",
      title = "Magnetic Contactor Holding Circuit",
      subtitle = "2-Wire / 3-Wire Control with Thermal Overload",
      difficulty = "Beginner",
      description = "The foundational industrial circuit used in manufacturing facilities worldwide. Pressing Start energizes KM1, which closes auxiliary contact 13-14 to seal the circuit in. Thermal overload relay FR1 monitors current; pressing Test Trip or stopping drops out the contactor.",
      objective = "Close Q2 breaker, press Start SB2 to engage the latch. Verify Green RUN light lights up. Release Start and confirm it stays latched. Test Emergency Stop or Overload trip.",
      components = listOf(acPwr, q2, sb0, sb1, sb2, km1, fr1, hl1, hl2),
      initialWires = wires
    )
  }

  private fun createSmpsAndSensorsScenario(): CircuitScenario {
    val acPwr = ComponentFactory.createComponent(ComponentType.AC_SOURCE_3P, "pwr1", "AC Supply", 40f, 40f)
    val smps = ComponentFactory.createComponent(ComponentType.SMPS_24V, "ps1", "SMPS 24V", 220f, 40f)
    val sq1 = ComponentFactory.createComponent(ComponentType.INDUCTIVE_SENSOR, "sq1", "Proximity SQ1", 420f, 40f)
    val sq2 = ComponentFactory.createComponent(ComponentType.PHOTOELECTRIC_SENSOR, "sq2", "Optical SQ2", 580f, 40f)
    val k1 = ComponentFactory.createComponent(ComponentType.CONTROL_RELAY, "k1", "Relay K1", 220f, 280f)
    val hl1 = ComponentFactory.createComponent(ComponentType.PILOT_LIGHT, "hl1", "Detect Lamp", 420f, 280f)
    val ha1 = ComponentFactory.createComponent(ComponentType.INDUSTRIAL_BUZZER, "ha1", "Alarm Buzzer", 580f, 280f)

    val wires = mutableListOf(
      // AC Mains to SMPS
      Wire("w1", "pwr1", "L1", "ps1", "L", WireColor.L1_BROWN),
      Wire("w2", "pwr1", "N", "ps1", "N", WireColor.N_BLUE),
      Wire("w3", "pwr1", "PE", "ps1", "PE", WireColor.PE_EARTH),
      // SMPS +24V to Inductive Sensor SQ1
      Wire("w4", "ps1", "+24V", "sq1", "+24V", WireColor.DC_POS_RED),
      Wire("w5", "ps1", "0V", "sq1", "0V", WireColor.DC_NEG_BLUE),
      // SQ1 PNP Output to Relay K1 Coil A1
      Wire("w6", "sq1", "OUT", "k1", "A1", WireColor.CONTROL_PURPLE),
      Wire("w7", "ps1", "0V", "k1", "A2", WireColor.DC_NEG_BLUE),
      // Relay Contact 11-14 to Detect Lamp
      Wire("w8", "ps1", "+24V", "k1", "11", WireColor.DC_POS_RED),
      Wire("w9", "k1", "14", "hl1", "X1", WireColor.CONTROL_PURPLE),
      Wire("w10", "ps1", "0V", "hl1", "X2", WireColor.DC_NEG_BLUE),
      // Optical sensor SQ2 power and buzzer
      Wire("w11", "ps1", "+24V", "sq2", "+24V", WireColor.DC_POS_RED),
      Wire("w12", "ps1", "0V", "sq2", "0V", WireColor.DC_NEG_BLUE),
      Wire("w13", "sq2", "OUT", "ha1", "X1", WireColor.CONTROL_PURPLE),
      Wire("w14", "ps1", "0V", "ha1", "X2", WireColor.DC_NEG_BLUE)
    )

    return CircuitScenario(
      id = "smps_sensors",
      title = "24V SMPS & Sensor Automation",
      subtitle = "DC Power Supply, Inductive Sensor & Industrial Relay",
      difficulty = "Intermediate",
      description = "Converts 230V AC to stable 24V DC using an industrial Switched-Mode Power Supply. Powers an inductive proximity sensor (for metal parts) and a photoelectric retroreflective sensor. Triggers relay K1 and alarm indicators upon target detection.",
      objective = "Observe SMPS 24V output regulation. Toggle the metal target proximity on SQ1 or beam obstruction on SQ2 to see the relay contacts switch and alarm activate.",
      components = listOf(acPwr, smps, sq1, sq2, k1, hl1, ha1),
      initialWires = wires
    )
  }

  private fun createPlcAutomationScenario(): CircuitScenario {
    val acPwr = ComponentFactory.createComponent(ComponentType.AC_SOURCE_3P, "pwr1", "AC Supply", 40f, 40f)
    val smps = ComponentFactory.createComponent(ComponentType.SMPS_24V, "ps1", "SMPS 24V", 220f, 40f)
    val sb1 = ComponentFactory.createComponent(ComponentType.PUSH_BUTTON_STOP, "sb1", "Stop PB", 420f, 40f)
    val sb2 = ComponentFactory.createComponent(ComponentType.PUSH_BUTTON_START, "sb2", "Start PB", 560f, 40f)
    val sq1 = ComponentFactory.createComponent(ComponentType.INDUCTIVE_SENSOR, "sq1", "Part Sensor", 700f, 40f)
    val plc = ComponentFactory.createComponent(ComponentType.PLC_CONTROLLER, "plc1", "PLC-S7", 200f, 260f)
    val km1 = ComponentFactory.createComponent(ComponentType.MAGNETIC_CONTACTOR, "km1", "Conveyor Motor KM", 480f, 260f)
    val hl1 = ComponentFactory.createComponent(ComponentType.PILOT_LIGHT, "hl1", "Running Lamp", 680f, 260f)

    val wires = mutableListOf(
      Wire("w1", "pwr1", "L1", "ps1", "L", WireColor.L1_BROWN),
      Wire("w2", "pwr1", "N", "ps1", "N", WireColor.N_BLUE),
      // SMPS DC to PLC Power
      Wire("w3", "ps1", "+24V", "plc1", "L+", WireColor.DC_POS_RED),
      Wire("w4", "ps1", "0V", "plc1", "M", WireColor.DC_NEG_BLUE),
      // Start PB to PLC I0.0
      Wire("w5", "ps1", "+24V", "sb2", "13", WireColor.DC_POS_RED),
      Wire("w6", "sb2", "14", "plc1", "I0.0", WireColor.CONTROL_PURPLE),
      // Stop PB to PLC I0.1
      Wire("w7", "ps1", "+24V", "sb1", "11", WireColor.DC_POS_RED),
      Wire("w8", "sb1", "12", "plc1", "I0.1", WireColor.CONTROL_PURPLE),
      // Sensor to PLC I0.2
      Wire("w9", "ps1", "+24V", "sq1", "+24V", WireColor.DC_POS_RED),
      Wire("w10", "ps1", "0V", "sq1", "0V", WireColor.DC_NEG_BLUE),
      Wire("w11", "sq1", "OUT", "plc1", "I0.2", WireColor.CONTROL_PURPLE),
      // PLC Common 1L
      Wire("w12", "ps1", "+24V", "plc1", "1L", WireColor.DC_POS_RED),
      // PLC Q0.0 (Conveyor Contactor)
      Wire("w13", "plc1", "Q0.0", "km1", "A1", WireColor.CONTROL_PURPLE),
      Wire("w14", "ps1", "0V", "km1", "A2", WireColor.DC_NEG_BLUE),
      // PLC Q0.1 (Running Lamp)
      Wire("w15", "plc1", "Q0.1", "hl1", "X1", WireColor.CONTROL_PURPLE),
      Wire("w16", "ps1", "0V", "hl1", "X2", WireColor.DC_NEG_BLUE)
    )

    // Pre-loaded industrial Ladder Logic Program:
    // Rung 0: [I0.0 Start OR M0.0 Latch] AND [/I0.1 Stop] -> (M0.0 Internal Run Relay)
    // Rung 1: [M0.0] AND [I0.2 Part Sensor] -> (Q0.0 Conveyor Contactor)
    // Rung 2: [M0.0] -> (Q0.1 Run Light)
    val ladderProgram = PlcProgram(
      rungs = listOf(
        PlcLadderRung(
          id = "rung_0",
          rungNumber = 0,
          comment = "Conveyor Master Run Latch (Start / Stop Control)",
          instructions = listOf(
            PlcInstruction("i0", PlcInstructionType.CONTACT_NO, "I0.0"),
            PlcInstruction("i1", PlcInstructionType.CONTACT_NC, "I0.1")
          ),
          outputInstruction = PlcInstruction("out0", PlcInstructionType.COIL_NORMAL, "M0.0")
        ),
        PlcLadderRung(
          id = "rung_1",
          rungNumber = 1,
          comment = "Drive Motor Output gated by Part Sensor Detection",
          instructions = listOf(
            PlcInstruction("i2", PlcInstructionType.CONTACT_NO, "M0.0"),
            PlcInstruction("i3", PlcInstructionType.CONTACT_NO, "I0.2")
          ),
          outputInstruction = PlcInstruction("out1", PlcInstructionType.COIL_NORMAL, "Q0.0")
        ),
        PlcLadderRung(
          id = "rung_2",
          rungNumber = 2,
          comment = "Stack Light Status Indicator",
          instructions = listOf(
            PlcInstruction("i4", PlcInstructionType.CONTACT_NO, "M0.0")
          ),
          outputInstruction = PlcInstruction("out2", PlcInstructionType.COIL_NORMAL, "Q0.1")
        )
      )
    )

    return CircuitScenario(
      id = "plc_conveyor",
      title = "PLC Industrial Conveyor Automation",
      subtitle = "Micro-PLC with Live Ladder Logic Simulation",
      difficulty = "Intermediate",
      description = "Modern automated manufacturing cell. Features physical inputs (Start, Stop, Part Presence Sensor) wired to PLC digital inputs, and physical outputs driving motor contactor KM1 and stack light HL1. Includes live ladder logic rung execution.",
      objective = "Press Start PB, view the ladder rungs highlight in glowing electric green, toggle the proximity sensor to detect parts, and watch Output Q0.0 engage the motor contactor.",
      components = listOf(acPwr, smps, sb1, sb2, sq1, plc, km1, hl1),
      initialWires = wires,
      initialPlcProgram = ladderProgram
    )
  }

  private fun createForwardReverseScenario(): CircuitScenario {
    val acPwr = ComponentFactory.createComponent(ComponentType.AC_SOURCE_3P, "pwr1", "AC Supply", 40f, 40f)
    val q1 = ComponentFactory.createComponent(ComponentType.CIRCUIT_BREAKER_3P, "q1", "Q1 Breaker", 240f, 40f)
    val km1 = ComponentFactory.createComponent(ComponentType.MAGNETIC_CONTACTOR, "km1", "KM1 (Forward)", 80f, 260f)
    val km2 = ComponentFactory.createComponent(ComponentType.MAGNETIC_CONTACTOR, "km2", "KM2 (Reverse)", 320f, 260f)
    val motor = ComponentFactory.createComponent(ComponentType.MOTOR_3PHASE, "m1", "M1 Motor", 200f, 520f)
    val sb1 = ComponentFactory.createComponent(ComponentType.PUSH_BUTTON_START, "sb1", "FWD Start", 540f, 40f)
    val sb2 = ComponentFactory.createComponent(ComponentType.PUSH_BUTTON_START, "sb2", "REV Start", 680f, 40f)

    val wires = mutableListOf(
      Wire("w1", "pwr1", "L1", "q1", "1/L1", WireColor.L1_BROWN),
      Wire("w2", "pwr1", "L2", "q1", "3/L2", WireColor.L2_BLACK),
      Wire("w3", "pwr1", "L3", "q1", "5/L3", WireColor.L3_GREY),
      // Forward Contactor KM1
      Wire("w4", "q1", "2/T1", "km1", "1/L1", WireColor.L1_BROWN),
      Wire("w5", "q1", "4/T2", "km1", "3/L2", WireColor.L2_BLACK),
      Wire("w6", "q1", "6/T3", "km1", "5/L3", WireColor.L3_GREY),
      Wire("w7", "km1", "2/T1", "m1", "U1", WireColor.L1_BROWN),
      Wire("w8", "km1", "4/T2", "m1", "V1", WireColor.L2_BLACK),
      Wire("w9", "km1", "6/T3", "m1", "W1", WireColor.L3_GREY),
      // Reverse Contactor KM2 (Phases L1 and L3 swapped!)
      Wire("w10", "q1", "2/T1", "km2", "5/L3", WireColor.L1_BROWN),
      Wire("w11", "q1", "4/T2", "km2", "3/L2", WireColor.L2_BLACK),
      Wire("w12", "q1", "6/T3", "km2", "1/L1", WireColor.L3_GREY),
      Wire("w13", "km2", "2/T1", "m1", "U1", WireColor.L1_BROWN),
      Wire("w14", "km2", "4/T2", "m1", "V1", WireColor.L2_BLACK),
      Wire("w15", "km2", "6/T3", "m1", "W1", WireColor.L3_GREY),
      // Control with NC Interlocks: KM1 coil through KM2 NC (21-22), KM2 coil through KM1 NC (21-22)
      Wire("w16", "q1", "2/T1", "sb1", "13", WireColor.CONTROL_PURPLE),
      Wire("w17", "sb1", "14", "km2", "21", WireColor.CONTROL_PURPLE),
      Wire("w18", "km2", "22", "km1", "A1", WireColor.CONTROL_PURPLE),
      Wire("w19", "pwr1", "N", "km1", "A2", WireColor.N_BLUE),
      // Reverse control
      Wire("w20", "q1", "2/T1", "sb2", "13", WireColor.CONTROL_PURPLE),
      Wire("w21", "sb2", "14", "km1", "21", WireColor.CONTROL_PURPLE),
      Wire("w22", "km1", "22", "km2", "A1", WireColor.CONTROL_PURPLE),
      Wire("w23", "pwr1", "N", "km2", "A2", WireColor.N_BLUE)
    )

    return CircuitScenario(
      id = "fwd_rev",
      title = "Forward / Reverse Interlocked Starter",
      subtitle = "Phase Inversion & Anti-Short Circuit Protection",
      difficulty = "Intermediate",
      description = "Reverses induction motor rotation by swapping two line phases (L1 and L3). Demonstrates the critical importance of electrical and mechanical interlocking: if both contactors close simultaneously, a 400V phase-to-phase dead short explodes across the contacts.",
      objective = "Test Forward rotation (CW), then switch to Reverse (CCW). Try removing the NC interlock wire to observe how the real-time debugger catches the short-circuit hazard.",
      components = listOf(acPwr, q1, km1, km2, motor, sb1, sb2),
      initialWires = wires
    )
  }

  private fun createFreeformSandboxScenario(): CircuitScenario {
    val acPwr = ComponentFactory.createComponent(ComponentType.AC_SOURCE_3P, "pwr1", "AC Supply", 60f, 60f)
    val smps = ComponentFactory.createComponent(ComponentType.SMPS_24V, "ps1", "SMPS 24V", 260f, 60f)
    val km1 = ComponentFactory.createComponent(ComponentType.MAGNETIC_CONTACTOR, "km1", "KM1", 460f, 60f)

    return CircuitScenario(
      id = "sandbox",
      title = "Freeform Industrial Sandbox",
      subtitle = "Custom Circuit Design & Component Workspace",
      difficulty = "All Levels",
      description = "Blank DIN rail canvas. Add any industrial automation components from the bottom toolbar (Breakers, Contactors, Relays, Motors, Sensors, SMPS, PLC, Pilot Lamps), drag and position them, wire terminals, and run live diagnostic simulations.",
      objective = "Build and test any custom electrical or control circuit of your choice.",
      components = listOf(acPwr, smps, km1),
      initialWires = emptyList()
    )
  }
}
