package com.example.simulation

import com.example.model.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CircuitEngine {

  private val dateFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

  class PinState(
    var potentialVolts: Float = 0f,
    var voltageType: VoltageType = VoltageType.SIGNAL,
    var isPhase: Boolean = false,
    var isNeutral: Boolean = false,
    var isDcPos: Boolean = false,
    var isDcNeg: Boolean = false,
    var isGround: Boolean = false
  )

  fun simulate(
    components: List<CircuitComponent>,
    wires: List<Wire>,
    deltaSeconds: Float,
    plcProgram: PlcProgram
  ): SimulationResult {
    val logs = mutableListOf<DiagnosticLog>()
    val detectedIssues = mutableListOf<DiagnosticIssue>()

    var hasShortCircuit = false
    var shortCircuitDescription = ""
    val faultyWireIds = mutableSetOf<String>()
    val faultyComponentIds = mutableSetOf<String>()

    // Map components by ID for quick lookup
    val componentMap = components.associateBy { it.id }.toMutableMap()

    // 1. Identify Power Sources
    val acSources = components.filter { it.type == ComponentType.AC_SOURCE_3P }
    val smpsUnits = components.filter { it.type == ComponentType.SMPS_24V }

    val pinStates = mutableMapOf<Pair<String, String>, PinState>()

    // Initialize all pins to 0V
    components.forEach { comp ->
      comp.pins.forEach { pin ->
        pinStates[Pair(comp.id, pin.id)] = PinState(voltageType = pin.voltageType)
      }
    }

    // Energize AC Source pins
    acSources.forEach { ac ->
      pinStates[Pair(ac.id, "L1")]?.apply {
        potentialVolts = 230f
        isPhase = true
        voltageType = VoltageType.AC_L1
      }
      pinStates[Pair(ac.id, "L2")]?.apply {
        potentialVolts = 230f
        isPhase = true
        voltageType = VoltageType.AC_L2
      }
      pinStates[Pair(ac.id, "L3")]?.apply {
        potentialVolts = 230f
        isPhase = true
        voltageType = VoltageType.AC_L3
      }
      pinStates[Pair(ac.id, "N")]?.apply {
        potentialVolts = 0f
        isNeutral = true
        voltageType = VoltageType.AC_N
      }
      pinStates[Pair(ac.id, "PE")]?.apply {
        potentialVolts = 0f
        isGround = true
        voltageType = VoltageType.PE
      }
    }

    // Graph connection representation: pin -> list of (connectedPin, wire)
    val adjacency = mutableMapOf<Pair<String, String>, MutableList<Pair<Pair<String, String>, Wire>>>()
    wires.forEach { wire ->
      val p1 = Pair(wire.fromComponentId, wire.fromPinId)
      val p2 = Pair(wire.toComponentId, wire.toPinId)
      adjacency.getOrPut(p1) { mutableListOf() }.add(Pair(p2, wire))
      adjacency.getOrPut(p2) { mutableListOf() }.add(Pair(p1, wire))
    }

    // Multi-pass potential propagation & component switching solver
    val maxPasses = 5
    var pass = 0

    while (pass < maxPasses) {
      pass++

      // Propagate electrical potentials across wires and closed component paths
      var changed = true
      var iter = 0
      while (changed && iter < 10) {
        iter++
        changed = false

        // Propagate across wires
        wires.forEach { wire ->
          val p1 = Pair(wire.fromComponentId, wire.fromPinId)
          val p2 = Pair(wire.toComponentId, wire.toPinId)
          val s1 = pinStates[p1]
          val s2 = pinStates[p2]

          if (s1 != null && s2 != null) {
            // Check for direct Short Circuit (Phase to Neutral / Phase to Ground / Phase to Phase without load)
            if (s1.isPhase && (s2.isNeutral || s2.isGround)) {
              hasShortCircuit = true
              shortCircuitDescription = "Dead Short-Circuit: Phase ${s1.voltageType} connected directly to ${if (s2.isNeutral) "Neutral" else "PE Earth"}!"
              faultyWireIds.add(wire.id)
              faultyComponentIds.add(wire.fromComponentId)
              faultyComponentIds.add(wire.toComponentId)
            }
            if (s1.isPhase && s2.isPhase && s1.voltageType != s2.voltageType) {
              // Phase to phase direct short
              hasShortCircuit = true
              shortCircuitDescription = "Dead Short-Circuit: Phase-to-Phase Short (${s1.voltageType} and ${s2.voltageType})!"
              faultyWireIds.add(wire.id)
              faultyComponentIds.add(wire.fromComponentId)
              faultyComponentIds.add(wire.toComponentId)
            }
            if (s1.isDcPos && s2.isDcNeg) {
              hasShortCircuit = true
              shortCircuitDescription = "DC Short-Circuit: +24V connected directly to 0V DC!"
              faultyWireIds.add(wire.id)
              faultyComponentIds.add(wire.fromComponentId)
              faultyComponentIds.add(wire.toComponentId)
            }

            // Transfer potential
            if (s1.potentialVolts > 0f && s2.potentialVolts == 0f && !s2.isNeutral && !s2.isGround && !s2.isDcNeg) {
              s2.potentialVolts = s1.potentialVolts
              s2.voltageType = s1.voltageType
              s2.isPhase = s1.isPhase
              s2.isDcPos = s1.isDcPos
              changed = true
            } else if (s2.potentialVolts > 0f && s1.potentialVolts == 0f && !s1.isNeutral && !s1.isGround && !s1.isDcNeg) {
              s1.potentialVolts = s2.potentialVolts
              s1.voltageType = s2.voltageType
              s1.isPhase = s2.isPhase
              s1.isDcPos = s2.isDcPos
              changed = true
            }

            // Propagate Neutral & 0V return reference
            if (s1.isNeutral && !s2.isNeutral && !s2.isPhase && !s2.isDcPos) {
              s2.isNeutral = true
              changed = true
            }
            if (s2.isNeutral && !s1.isNeutral && !s1.isPhase && !s1.isDcPos) {
              s1.isNeutral = true
              changed = true
            }
            if (s1.isDcNeg && !s2.isDcNeg && !s2.isDcPos && !s2.isPhase) {
              s2.isDcNeg = true
              changed = true
            }
            if (s2.isDcNeg && !s1.isDcNeg && !s1.isDcPos && !s1.isPhase) {
              s1.isDcNeg = true
              changed = true
            }
          }
        }

        // Propagate internally through closed components
        components.forEach { comp ->
          when (comp.type) {
            ComponentType.CIRCUIT_BREAKER_3P -> {
              if (comp.isClosed && !comp.isTripped) {
                // Bridge L1->T1, L2->T2, L3->T3
                bridgePins(comp.id, "1/L1", "2/T1", pinStates)?.let { changed = changed || it }
                bridgePins(comp.id, "3/L2", "4/T2", pinStates)?.let { changed = changed || it }
                bridgePins(comp.id, "5/L3", "6/T3", pinStates)?.let { changed = changed || it }
              }
            }
            ComponentType.CIRCUIT_BREAKER_1P -> {
              if (comp.isClosed && !comp.isTripped) {
                bridgePins(comp.id, "1/L", "2/T", pinStates)?.let { changed = changed || it }
              }
            }
            ComponentType.PUSH_BUTTON_START -> {
              if (comp.isClosed) { // momentary pressed
                bridgePins(comp.id, "13", "14", pinStates)?.let { changed = changed || it }
              }
            }
            ComponentType.PUSH_BUTTON_STOP, ComponentType.EMERGENCY_STOP -> {
              if (!comp.isClosed) { // NC conducts when NOT pressed (isClosed=false means resting NC closed)
                bridgePins(comp.id, "11", "12", pinStates)?.let { changed = changed || it }
              }
            }
            ComponentType.MAGNETIC_CONTACTOR -> {
              if (comp.isEnergized) {
                // Main power contacts 1-2, 3-4, 5-6 closed
                bridgePins(comp.id, "1/L1", "2/T1", pinStates)?.let { changed = changed || it }
                bridgePins(comp.id, "3/L2", "4/T2", pinStates)?.let { changed = changed || it }
                bridgePins(comp.id, "5/L3", "6/T3", pinStates)?.let { changed = changed || it }
                // Auxiliary NO 13-14 closed
                bridgePins(comp.id, "13", "14", pinStates)?.let { changed = changed || it }
              } else {
                // Auxiliary NC 21-22 closed when de-energized
                bridgePins(comp.id, "21", "22", pinStates)?.let { changed = changed || it }
              }
            }
            ComponentType.CONTROL_RELAY -> {
              if (comp.isEnergized) {
                // NO contacts closed: 11-14, 21-24
                bridgePins(comp.id, "11", "14", pinStates)?.let { changed = changed || it }
                bridgePins(comp.id, "21", "24", pinStates)?.let { changed = changed || it }
              } else {
                // NC contacts closed: 11-12, 21-22
                bridgePins(comp.id, "11", "12", pinStates)?.let { changed = changed || it }
                bridgePins(comp.id, "21", "22", pinStates)?.let { changed = changed || it }
              }
            }
            ComponentType.TIMER_RELAY -> {
              if (comp.timerElapsedSec >= comp.timerSetSec) {
                // Timed NO 15-18 closed
                bridgePins(comp.id, "15", "18", pinStates)?.let { changed = changed || it }
              } else {
                // Timed NC 15-16 closed
                bridgePins(comp.id, "15", "16", pinStates)?.let { changed = changed || it }
              }
            }
            ComponentType.THERMAL_OVERLOAD -> {
              if (!comp.isTripped) {
                // Through-bus 1-2, 3-4, 5-6
                bridgePins(comp.id, "1/L1", "2/T1", pinStates)?.let { changed = changed || it }
                bridgePins(comp.id, "3/L2", "4/T2", pinStates)?.let { changed = changed || it }
                bridgePins(comp.id, "5/L3", "6/T3", pinStates)?.let { changed = changed || it }
                // 95-96 NC closed
                bridgePins(comp.id, "95", "96", pinStates)?.let { changed = changed || it }
              } else {
                // 97-98 NO alarm closed
                bridgePins(comp.id, "97", "98", pinStates)?.let { changed = changed || it }
              }
            }
            ComponentType.LIMIT_SWITCH -> {
              if (comp.sensorActive) {
                bridgePins(comp.id, "COM", "NO", pinStates)?.let { changed = changed || it }
              } else {
                bridgePins(comp.id, "COM", "NC", pinStates)?.let { changed = changed || it }
              }
            }
            else -> {}
          }
        }
      }

      // Check SMPS AC in -> DC out activation
      smpsUnits.forEach { smps ->
        val lState = pinStates[Pair(smps.id, "L")]
        val nState = pinStates[Pair(smps.id, "N")]
        val isSmpsPowered = (lState?.potentialVolts ?: 0f) > 180f && (nState?.isNeutral == true)
        val posPin = pinStates[Pair(smps.id, "+24V")]
        val negPin = pinStates[Pair(smps.id, "0V")]

        if (isSmpsPowered) {
          posPin?.apply {
            potentialVolts = 24f
            isDcPos = true
            voltageType = VoltageType.DC_POS
          }
          negPin?.apply {
            potentialVolts = 0f
            isDcNeg = true
            voltageType = VoltageType.DC_NEG
          }
          componentMap[smps.id] = componentMap[smps.id]!!.copy(isEnergized = true)
        } else {
          posPin?.apply {
            potentialVolts = 0f
            isDcPos = false
          }
          negPin?.apply { isDcNeg = false }
          componentMap[smps.id] = componentMap[smps.id]!!.copy(isEnergized = false)
        }
      }

      // Check Sensor Outputs (Inductive & Photoelectric)
      components.forEach { comp ->
        if (comp.type == ComponentType.INDUCTIVE_SENSOR || comp.type == ComponentType.PHOTOELECTRIC_SENSOR) {
          val vcc = pinStates[Pair(comp.id, "+24V")]
          val gnd = pinStates[Pair(comp.id, "0V")]
          val isPowered = (vcc?.potentialVolts ?: 0f) >= 20f && (gnd?.isDcNeg == true)
          val outPin = pinStates[Pair(comp.id, "OUT")]

          if (isPowered && comp.sensorActive) {
            outPin?.apply {
              potentialVolts = 24f
              isDcPos = true
              voltageType = VoltageType.DC_POS
            }
            componentMap[comp.id] = componentMap[comp.id]!!.copy(isEnergized = true)
          } else {
            outPin?.apply {
              potentialVolts = 0f
              isDcPos = false
            }
            componentMap[comp.id] = componentMap[comp.id]!!.copy(isEnergized = isPowered)
          }
        }
      }

      // Check Contactor & Relay Coil Energization
      components.forEach { comp ->
        when (comp.type) {
          ComponentType.MAGNETIC_CONTACTOR, ComponentType.CONTROL_RELAY -> {
            val a1 = pinStates[Pair(comp.id, "A1")]
            val a2 = pinStates[Pair(comp.id, "A2")]
            // Energized if A1 has potential and A2 has return path (Neutral or 0V)
            val hasVoltage = (a1?.potentialVolts ?: 0f) >= 20f
            val hasReturn = (a2?.isNeutral == true || a2?.isDcNeg == true)
            val newlyEnergized = hasVoltage && hasReturn

            val oldEnergized = comp.isEnergized
            if (newlyEnergized != oldEnergized) {
              componentMap[comp.id] = comp.copy(isEnergized = newlyEnergized)
              if (newlyEnergized) {
                logs.add(
                  DiagnosticLog(
                    timestamp = dateFormat.format(Date()),
                    level = LogLevel.SUCCESS,
                    tag = comp.tag,
                    message = "${comp.name} (${comp.tag}) Coil A1-A2 ENERGIZED! Plunger pulled in, contacts shifted."
                  )
                )
              } else {
                logs.add(
                  DiagnosticLog(
                    timestamp = dateFormat.format(Date()),
                    level = LogLevel.INFO,
                    tag = comp.tag,
                    message = "${comp.name} (${comp.tag}) Coil de-energized, contacts returned to normal."
                  )
                )
              }
            }
          }
          ComponentType.TIMER_RELAY -> {
            val a1 = pinStates[Pair(comp.id, "A1")]
            val a2 = pinStates[Pair(comp.id, "A2")]
            val hasPower = (a1?.potentialVolts ?: 0f) >= 20f && (a2?.isNeutral == true || a2?.isDcNeg == true)
            val currentElapsed = comp.timerElapsedSec
            val newElapsed = if (hasPower) {
              (currentElapsed + deltaSeconds).coerceAtMost(comp.timerSetSec)
            } else {
              0f
            }
            val wasExpired = currentElapsed >= comp.timerSetSec
            val nowExpired = newElapsed >= comp.timerSetSec

            if (!wasExpired && nowExpired) {
              logs.add(
                DiagnosticLog(
                  timestamp = dateFormat.format(Date()),
                  level = LogLevel.INFO,
                  tag = comp.tag,
                  message = "Timer ${comp.tag} reached preset ${comp.timerSetSec}s -> Timed contacts 15-18 (NO) CLOSED!"
                )
              )
            }
            componentMap[comp.id] = comp.copy(isEnergized = hasPower, timerElapsedSec = newElapsed)
          }
          else -> {}
        }
      }
    }

    // 2. PLC Ladder Execution
    val plcComponent = components.find { it.type == ComponentType.PLC_CONTROLLER }
    var updatedPlcProgram = plcProgram
    if (plcComponent != null) {
      val lPlus = pinStates[Pair(plcComponent.id, "L+")]
      val m = pinStates[Pair(plcComponent.id, "M")]
      val isPlcPowered = (lPlus?.potentialVolts ?: 0f) >= 20f && (m?.isDcNeg == true)

      if (isPlcPowered) {
        val inputStates = mapOf(
          "I0.0" to ((pinStates[Pair(plcComponent.id, "I0.0")]?.potentialVolts ?: 0f) >= 15f),
          "I0.1" to ((pinStates[Pair(plcComponent.id, "I0.1")]?.potentialVolts ?: 0f) >= 15f),
          "I0.2" to ((pinStates[Pair(plcComponent.id, "I0.2")]?.potentialVolts ?: 0f) >= 15f),
          "I0.3" to ((pinStates[Pair(plcComponent.id, "I0.3")]?.potentialVolts ?: 0f) >= 15f)
        )

        val (newProg, outputStates) = PlcEngine().executeScanCycle(plcProgram, inputStates, deltaSeconds)
        updatedPlcProgram = newProg

        outputStates.forEach { (qPin, isActive) ->
          val outState = pinStates[Pair(plcComponent.id, qPin)]
          if (isActive) {
            outState?.apply {
              potentialVolts = 24f
              isDcPos = true
              voltageType = VoltageType.DC_POS
            }
          } else {
            outState?.apply {
              potentialVolts = 0f
              isDcPos = false
            }
          }
        }
        componentMap[plcComponent.id] = plcComponent.copy(isEnergized = true)
      } else {
        componentMap[plcComponent.id] = plcComponent.copy(isEnergized = false)
      }
    }

    // 3. Evaluate 3-Phase Induction Motor & Star-Delta Circuit State
    val motors = components.filter { it.type == ComponentType.MOTOR_3PHASE }
    motors.forEach { motor ->
      val u1 = pinStates[Pair(motor.id, "U1")]
      val v1 = pinStates[Pair(motor.id, "V1")]
      val w1 = pinStates[Pair(motor.id, "W1")]
      val u2 = pinStates[Pair(motor.id, "U2")]
      val v2 = pinStates[Pair(motor.id, "V2")]
      val w2 = pinStates[Pair(motor.id, "W2")]

      val has3PhaseSupply = (u1?.potentialVolts ?: 0f) >= 200f &&
                            (v1?.potentialVolts ?: 0f) >= 200f &&
                            (w1?.potentialVolts ?: 0f) >= 200f

      // Check if U2, V2, W2 are bridged together (Star connection via Star Contactor)
      val starBridged = arePinsElectricallyBridged(motor.id, listOf("U2", "V2", "W2"), adjacency, components)

      // Check if Delta connections exist: U1-W2, V1-U2, W1-V2 (Delta connection via Delta Contactor)
      val deltaBridged = areDeltaConnected(motor.id, adjacency, components)

      // CRITICAL STAR-DELTA SHORT-CIRCUIT DETECTION:
      if (starBridged && deltaBridged) {
        hasShortCircuit = true
        shortCircuitDescription = "CRITICAL FAULT: Star Contactor & Delta Contactor closed simultaneously! Massive phase short-circuit on Motor W2/U2/V2 terminals!"
        faultyComponentIds.add(motor.id)
        detectedIssues.add(
          DiagnosticIssue(
            title = "Simultaneous Star & Delta Closure",
            description = "Both Star (KM3) and Delta (KM2) contactors are pulling in together. In physical hardware, this creates an instantaneous 400V phase-to-phase dead short across the busbars.",
            severity = "CRITICAL",
            recommendation = "Add electrical interlocks: Wire KM3 coil through KM2 NC contact (21-22), and KM2 coil through KM3 NC contact (21-22)."
          )
        )
      }

      val newRpm: Float
      val newMode: String
      if (!hasShortCircuit && has3PhaseSupply) {
        if (deltaBridged) {
          newMode = "DELTA"
          newRpm = 2920f
        } else if (starBridged) {
          newMode = "STAR"
          newRpm = 1440f
        } else {
          newMode = "UNBALANCED"
          newRpm = 0f
        }
      } else {
        newMode = "OFF"
        newRpm = 0f
      }

      val currentRpm = motor.motorRpm
      val smoothedRpm = if (newRpm > currentRpm) {
        (currentRpm + (newRpm - currentRpm) * (deltaSeconds * 3f)).coerceAtMost(newRpm)
      } else {
        (currentRpm - 1200f * deltaSeconds).coerceAtLeast(0f)
      }

      componentMap[motor.id] = motor.copy(
        isEnergized = smoothedRpm > 10f,
        motorRpm = smoothedRpm,
        motorMode = newMode
      )
    }

    // 4. Pilot Lights & Buzzer
    components.filter { it.type == ComponentType.PILOT_LIGHT || it.type == ComponentType.INDUSTRIAL_BUZZER }.forEach { act ->
      val x1 = pinStates[Pair(act.id, "X1")]
      val x2 = pinStates[Pair(act.id, "X2")]
      val isLit = (x1?.potentialVolts ?: 0f) >= 15f && (x2?.isNeutral == true || x2?.isDcNeg == true)
      componentMap[act.id] = act.copy(isEnergized = isLit)
    }

    // 5. Update energized wire statuses
    val updatedWires = wires.map { wire ->
      val p1 = pinStates[Pair(wire.fromComponentId, wire.fromPinId)]
      val p2 = pinStates[Pair(wire.toComponentId, wire.toPinId)]
      val isEnergized = (p1?.potentialVolts ?: 0f) > 10f || (p2?.potentialVolts ?: 0f) > 10f
      val isFaulty = faultyWireIds.contains(wire.id)
      wire.copy(
        isEnergized = isEnergized && !hasShortCircuit,
        isShortCircuit = isFaulty || (hasShortCircuit && isEnergized),
        currentAmps = if (isEnergized) 2.4f else 0f
      )
    }

    // 6. Assemble component pins with resolved potentials
    val updatedComponents = componentMap.values.map { comp ->
      val resolvedPins = comp.pins.map { pin ->
        val state = pinStates[Pair(comp.id, pin.id)]
        pin.copy(
          potentialVolts = state?.potentialVolts ?: 0f,
          isEnergized = (state?.potentialVolts ?: 0f) > 10f || state?.isNeutral == true || state?.isDcNeg == true
        )
      }

      val isCompFaulty = faultyComponentIds.contains(comp.id) || (hasShortCircuit && comp.isEnergized)
      comp.copy(
        pins = resolvedPins,
        isShortCircuited = isCompFaulty,
        faultMessage = if (isCompFaulty) shortCircuitDescription else null
      )
    }

    if (hasShortCircuit) {
      logs.add(
        DiagnosticLog(
          timestamp = dateFormat.format(Date()),
          level = LogLevel.FAULT,
          tag = "TRIP",
          message = shortCircuitDescription,
          remedy = "Inspect wiring between source phases and ground/neutral or verify interlocks."
        )
      )
    }

    val finalState = when {
      hasShortCircuit -> SimulationState.SHORT_CIRCUIT_TRIPPED
      components.any { it.isEnergized } -> SimulationState.RUNNING
      else -> SimulationState.STANDBY
    }

    return SimulationResult(
      components = updatedComponents,
      wires = updatedWires,
      plcProgram = updatedPlcProgram,
      simulationState = finalState,
      hasShortCircuit = hasShortCircuit,
      shortCircuitDescription = shortCircuitDescription,
      diagnosticLogs = logs,
      detectedIssues = detectedIssues
    )
  }

  private fun bridgePins(
    componentId: String,
    pinA: String,
    pinB: String,
    pinStates: MutableMap<Pair<String, String>, PinState>
  ): Boolean {
    val sA = pinStates[Pair(componentId, pinA)] ?: return false
    val sB = pinStates[Pair(componentId, pinB)] ?: return false
    var changed = false

    if (sA.potentialVolts > 0f && sB.potentialVolts == 0f) {
      sB.potentialVolts = sA.potentialVolts
      sB.voltageType = sA.voltageType
      sB.isPhase = sA.isPhase
      sB.isDcPos = sA.isDcPos
      changed = true
    } else if (sB.potentialVolts > 0f && sA.potentialVolts == 0f) {
      sA.potentialVolts = sB.potentialVolts
      sA.voltageType = sB.voltageType
      sA.isPhase = sB.isPhase
      sA.isDcPos = sB.isDcPos
      changed = true
    }

    if (sA.isNeutral && !sB.isNeutral) { sB.isNeutral = true; changed = true }
    if (sB.isNeutral && !sA.isNeutral) { sA.isNeutral = true; changed = true }
    if (sA.isDcNeg && !sB.isDcNeg) { sB.isDcNeg = true; changed = true }
    if (sB.isDcNeg && !sA.isDcNeg) { sA.isDcNeg = true; changed = true }

    return changed
  }

  private fun arePinsElectricallyBridged(
    motorId: String,
    pinNames: List<String>,
    adjacency: Map<Pair<String, String>, List<Pair<Pair<String, String>, Wire>>>,
    components: List<CircuitComponent>
  ): Boolean {
    // Check if pins in pinNames are connected through closed contactor/wires
    if (pinNames.size < 2) return false
    val p1 = Pair(motorId, pinNames[0])
    val visited = mutableSetOf<Pair<String, String>>()
    val queue = ArrayDeque<Pair<String, String>>()
    queue.add(p1)
    visited.add(p1)

    while (queue.isNotEmpty()) {
      val curr = queue.removeFirst()
      val neighbors = adjacency[curr] ?: emptyList()
      for ((nextPin, _) in neighbors) {
        if (visited.add(nextPin)) {
          queue.add(nextPin)
        }
      }
      // Also traverse closed contactors
      val comp = components.find { it.id == curr.first }
      if (comp != null && comp.type == ComponentType.MAGNETIC_CONTACTOR && comp.isEnergized) {
        // Contactor bridges 1-2, 3-4, 5-6
        val internalPartner = when (curr.second) {
          "1/L1" -> "2/T1"
          "2/T1" -> "1/L1"
          "3/L2" -> "4/T2"
          "4/T2" -> "3/L2"
          "5/L3" -> "6/T3"
          "6/T3" -> "5/L3"
          else -> null
        }
        if (internalPartner != null) {
          val partnerPin = Pair(comp.id, internalPartner)
          if (visited.add(partnerPin)) {
            queue.add(partnerPin)
          }
        }
      }
    }

    // Check if all pinNames are in visited
    return pinNames.all { visited.contains(Pair(motorId, it)) }
  }

  private fun areDeltaConnected(
    motorId: String,
    adjacency: Map<Pair<String, String>, List<Pair<Pair<String, String>, Wire>>>,
    components: List<CircuitComponent>
  ): Boolean {
    // Delta requires U1 connected to W2, V1 to U2, and W1 to V2
    // Check if KM2 (Delta Contactor) is energized and wired to motor terminals
    val deltaContactors = components.filter { it.type == ComponentType.MAGNETIC_CONTACTOR && it.tag.contains("KM2", ignoreCase = true) }
    if (deltaContactors.isEmpty()) return false
    val km2 = deltaContactors.first()
    return km2.isEnergized
  }
}

data class SimulationResult(
  val components: List<CircuitComponent>,
  val wires: List<Wire>,
  val plcProgram: PlcProgram,
  val simulationState: SimulationState,
  val hasShortCircuit: Boolean,
  val shortCircuitDescription: String,
  val diagnosticLogs: List<DiagnosticLog>,
  val detectedIssues: List<DiagnosticIssue>
)
