package com.example.simulation

import com.example.model.*

class PlcEngine {

  fun executeScanCycle(
    program: PlcProgram,
    inputStates: Map<String, Boolean>,
    deltaSeconds: Float
  ): Pair<PlcProgram, Map<String, Boolean>> {
    val variableTable = mutableMapOf<String, Boolean>()
    val timersMap = program.timers.toMutableMap()
    val markersMap = program.internalMarkers.toMutableMap()

    // 1. Load physical inputs
    inputStates.forEach { (pin, state) ->
      variableTable[pin] = state
    }
    // Load markers
    markersMap.forEach { (m, state) ->
      variableTable[m] = state
    }

    val updatedRungs = program.rungs.map { rung ->
      // Evaluate input contacts in series
      var rungCondition = true
      val updatedInstructions = rung.instructions.map { inst ->
        var isEnergized = false
        when (inst.type) {
          PlcInstructionType.CONTACT_NO -> {
            val operandVal = variableTable[inst.operand] ?: false
            isEnergized = rungCondition && operandVal
            rungCondition = isEnergized
            inst.copy(isEnergized = isEnergized)
          }
          PlcInstructionType.CONTACT_NC -> {
            val operandVal = variableTable[inst.operand] ?: false
            isEnergized = rungCondition && !operandVal
            rungCondition = isEnergized
            inst.copy(isEnergized = isEnergized)
          }
          PlcInstructionType.TIMER_ON_DELAY -> {
            val currentElapsed = timersMap[inst.operand] ?: 0f
            val newElapsed = if (rungCondition) {
              (currentElapsed + deltaSeconds).coerceAtMost(inst.presetSeconds)
            } else {
              0f
            }
            timersMap[inst.operand] = newElapsed
            val isDone = newElapsed >= inst.presetSeconds
            variableTable["${inst.operand}.DN"] = isDone
            isEnergized = isDone
            inst.copy(elapsedSeconds = newElapsed, isEnergized = isDone)
          }
          else -> inst
        }
      }

      // Evaluate output coil
      val updatedOutput = rung.outputInstruction?.let { outInst ->
        when (outInst.type) {
          PlcInstructionType.COIL_NORMAL -> {
            variableTable[outInst.operand] = rungCondition
            if (outInst.operand.startsWith("M")) {
              markersMap[outInst.operand] = rungCondition
            }
            outInst.copy(isEnergized = rungCondition)
          }
          PlcInstructionType.COIL_SET -> {
            if (rungCondition) {
              variableTable[outInst.operand] = true
              if (outInst.operand.startsWith("M")) markersMap[outInst.operand] = true
            }
            outInst.copy(isEnergized = variableTable[outInst.operand] ?: false)
          }
          PlcInstructionType.COIL_RESET -> {
            if (rungCondition) {
              variableTable[outInst.operand] = false
              if (outInst.operand.startsWith("M")) markersMap[outInst.operand] = false
            }
            outInst.copy(isEnergized = !(variableTable[outInst.operand] ?: false))
          }
          else -> outInst
        }
      }

      rung.copy(
        instructions = updatedInstructions,
        outputInstruction = updatedOutput,
        isRungActive = rungCondition
      )
    }

    // Extract outputs Q0.0 .. Q0.3
    val outputStates = mutableMapOf<String, Boolean>()
    listOf("Q0.0", "Q0.1", "Q0.2", "Q0.3").forEach { q ->
      outputStates[q] = variableTable[q] ?: false
    }

    val updatedProgram = program.copy(
      rungs = updatedRungs,
      internalMarkers = markersMap,
      timers = timersMap
    )

    return Pair(updatedProgram, outputStates)
  }
}
