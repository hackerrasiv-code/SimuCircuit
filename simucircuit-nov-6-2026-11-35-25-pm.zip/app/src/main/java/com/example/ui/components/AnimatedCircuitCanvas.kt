package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.example.model.*
import com.example.ui.theme.*
import kotlin.math.hypot

@Composable
fun AnimatedCircuitCanvas(
  components: List<CircuitComponent>,
  wires: List<Wire>,
  selectedComponentId: String?,
  selectedPin: Pin?,
  wiringDragCurrentPos: Offset?,
  currentWireColor: WireColor,
  isMultimeterActive: Boolean,
  onComponentSelect: (CircuitComponent) -> Unit,
  onComponentMove: (String, Float, Float) -> Unit,
  onPinClick: (CircuitComponent, Pin) -> Unit,
  onWireClick: (Wire) -> Unit,
  onCanvasTap: () -> Unit,
  modifier: Modifier = Modifier
) {
  // Infinite animation for flowing electron current particles
  val infiniteTransition = rememberInfiniteTransition(label = "electron_flow")
  val electronPhase by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 60f,
    animationSpec = infiniteRepeatable(
      animation = tween(1000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "electron_phase"
  )

  // Spark jitter for short circuits
  val sparkJitter by infiniteTransition.animateFloat(
    initialValue = -3f,
    targetValue = 3f,
    animationSpec = infiniteRepeatable(
      animation = tween(80, easing = LinearEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "spark_jitter"
  )

  // Map for fast pin coordinate lookup
  val pinCoordinateMap = remember(components) {
    val map = mutableMapOf<Pair<String, String>, Offset>()
    components.forEach { comp ->
      comp.pins.forEach { pin ->
        val absX = comp.x + pin.relativeOffset.x
        val absY = comp.y + pin.relativeOffset.y
        map[Pair(comp.id, pin.id)] = Offset(absX, absY)
      }
    }
    map
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(IndustrialBg)
      .pointerInput(Unit) {
        detectTapGestures {
          onCanvasTap()
        }
      }
  ) {
    // 1. DIN Rail and Grid Background
    Canvas(modifier = Modifier.fillMaxSize()) {
      val gridSize = 40.dp.toPx()
      val numX = (size.width / gridSize).toInt() + 1
      val numY = (size.height / gridSize).toInt() + 1

      // Subtle engineering grid dots
      for (x in 0..numX) {
        for (y in 0..numY) {
          drawCircle(
            color = IndustrialGridLine.copy(alpha = 0.6f),
            radius = 1.2f,
            center = Offset(x * gridSize, y * gridSize)
          )
        }
      }

      // DIN Rail Steel Mounting Tracks across the workspace
      val railHeights = listOf(140.dp.toPx(), 380.dp.toPx(), 640.dp.toPx())
      railHeights.forEach { railY ->
        drawRect(
          color = IndustrialDinRail.copy(alpha = 0.25f),
          topLeft = Offset(0f, railY),
          size = androidx.compose.ui.geometry.Size(size.width, 36.dp.toPx())
        )
        drawLine(
          color = IndustrialBorder,
          start = Offset(0f, railY),
          end = Offset(size.width, railY),
          strokeWidth = 1.5f
        )
        drawLine(
          color = IndustrialBorder,
          start = Offset(0f, railY + 36.dp.toPx()),
          end = Offset(size.width, railY + 36.dp.toPx()),
          strokeWidth = 1.5f
        )
      }
    }

    // 2. Animated Wires Layer
    Canvas(modifier = Modifier.fillMaxSize()) {
      wires.forEach { wire ->
        val p1 = pinCoordinateMap[Pair(wire.fromComponentId, wire.fromPinId)]
        val p2 = pinCoordinateMap[Pair(wire.toComponentId, wire.toPinId)]

        if (p1 != null && p2 != null) {
          val path = createCurvedWirePath(p1, p2)

          val baseWireColor = wire.color.color
          val isShort = wire.isShortCircuit
          val isEnergized = wire.isEnergized

          // Base wire stroke
          drawPath(
            path = path,
            color = if (isShort) FaultRed else baseWireColor,
            style = Stroke(width = if (isShort) 5f else 3.5f)
          )

          // Short-circuit violent spark & lightning effect
          if (isShort) {
            drawPath(
              path = path,
              color = Color.White,
              style = Stroke(
                width = 2.5f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), sparkJitter * 2f)
              )
            )
          } else if (isEnergized) {
            // Flowing electron dashes (current animation)
            drawPath(
              path = path,
              color = ElectricCyan,
              style = Stroke(
                width = 2.5f,
                pathEffect = PathEffect.dashPathEffect(
                  floatArrayOf(10f, 15f),
                  phase = -electronPhase
                )
              )
            )
          }
        }
      }

      // Drawing active dragging wire
      if (selectedPin != null && wiringDragCurrentPos != null) {
        val startPos = pinCoordinateMap[Pair(selectedPin.componentId, selectedPin.id)]
        if (startPos != null) {
          val dragPath = createCurvedWirePath(startPos, wiringDragCurrentPos)
          drawPath(
            path = dragPath,
            color = currentWireColor.color,
            style = Stroke(
              width = 3.5f,
              pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f), 0f)
            )
          )
        }
      }
    }

    // 3. Components Placed at Coordinates
    components.forEach { comp ->
      val isCompSelected = comp.id == selectedComponentId

      IndustrialComponentCard(
        component = comp,
        isSelected = isCompSelected,
        selectedPinId = if (selectedPin?.componentId == comp.id) selectedPin.id else null,
        onPinClick = { pin -> onPinClick(comp, pin) },
        onToggleAction = {
          // Manual action toggle (e.g. toggle breaker, press button, trigger overload)
          when (comp.type) {
            ComponentType.CIRCUIT_BREAKER_3P, ComponentType.CIRCUIT_BREAKER_1P -> {
              onComponentMove(comp.id, comp.x, comp.y) // will be handled via action in VM
            }
            else -> {}
          }
        },
        modifier = Modifier
          .offset(x = comp.x.dp, y = comp.y.dp)
          .pointerInput(comp.id) {
            detectDragGestures { change, dragAmount ->
              change.consume()
              onComponentMove(
                comp.id,
                (comp.x + dragAmount.x / density).coerceAtLeast(10f),
                (comp.y + dragAmount.y / density).coerceAtLeast(10f)
              )
            }
          }
      )
    }
  }
}

private fun createCurvedWirePath(start: Offset, end: Offset): Path {
  val path = Path()
  path.moveTo(start.x, start.y)

  val dx = end.x - start.x
  val dy = end.y - start.y
  val distance = hypot(dx, dy)

  // Industrial schematic wire routing: smooth cubic bezier with organic sag or orthogonal bend
  val controlOffset = (distance * 0.25f).coerceIn(20f, 80f)
  val cp1 = Offset(start.x, start.y + controlOffset)
  val cp2 = Offset(end.x, end.y - controlOffset)

  path.cubicTo(cp1.x, cp1.y, cp2.x, cp2.y, end.x, end.y)
  return path
}
