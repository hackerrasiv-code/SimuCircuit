package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun IndustrialComponentCard(
  component: CircuitComponent,
  isSelected: Boolean,
  selectedPinId: String?,
  onPinClick: (Pin) -> Unit,
  onToggleAction: () -> Unit,
  modifier: Modifier = Modifier
) {
  val isShort = component.isShortCircuited
  val isEnergized = component.isEnergized

  // Short-circuit flash shake
  val infiniteTransition = rememberInfiniteTransition(label = "flash")
  val shortPulse by infiniteTransition.animateFloat(
    initialValue = 0.8f,
    targetValue = 1.2f,
    animationSpec = infiniteRepeatable(
      animation = tween(120, easing = LinearEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "short_pulse"
  )

  val borderBrush = when {
    isShort -> Brush.linearGradient(listOf(FaultRed, ShortCircuitGlow, FaultRed))
    isSelected -> Brush.linearGradient(listOf(ElectricCyan, ElectricBlue))
    isEnergized -> Brush.linearGradient(listOf(ElectricCyan.copy(alpha = 0.8f), IndustrialBorder))
    else -> Brush.linearGradient(listOf(IndustrialBorder, IndustrialCardBg))
  }

  Box(
    modifier = modifier
      .width(component.width.dp)
      .height(component.height.dp)
      .shadow(
        elevation = if (isEnergized) 8.dp else 4.dp,
        shape = RoundedCornerShape(10.dp),
        ambientColor = if (isShort) FaultRed else if (isEnergized) ElectricCyan else Color.Black,
        spotColor = if (isShort) FaultRed else if (isEnergized) ElectricCyan else Color.Black
      )
      .clip(RoundedCornerShape(10.dp))
      .background(IndustrialCardBg)
      .border(
        width = if (isShort) (2.5f * shortPulse).dp else if (isSelected) 2.dp else 1.dp,
        brush = borderBrush,
        shape = RoundedCornerShape(10.dp)
      )
  ) {
    // Component Header with Tag and Title
    Column(modifier = Modifier.fillMaxSize()) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(IndustrialSurfaceVariant)
          .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = component.tag,
          color = if (isShort) FaultRed else if (isEnergized) ElectricCyan else TextPrimary,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace
        )

        // Status Indicator LED
        Box(
          modifier = Modifier
            .size(8.dp)
            .clip(CircleShape)
            .background(
              when {
                isShort -> FaultRed
                isEnergized -> SafeGreen
                else -> Color(0xFF374151)
              }
            )
        )
      }

      // Internal Visual Area for specific component type
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
          .padding(4.dp),
        contentAlignment = Alignment.Center
      ) {
        when (component.type) {
          ComponentType.MOTOR_3PHASE -> MotorVisual(component)
          ComponentType.MAGNETIC_CONTACTOR -> ContactorVisual(component, onToggleAction)
          ComponentType.TIMER_RELAY -> TimerVisual(component)
          ComponentType.CONTROL_RELAY -> RelayVisual(component)
          ComponentType.CIRCUIT_BREAKER_3P, ComponentType.CIRCUIT_BREAKER_1P -> BreakerVisual(component, onToggleAction)
          ComponentType.PUSH_BUTTON_START, ComponentType.PUSH_BUTTON_STOP, ComponentType.EMERGENCY_STOP -> PushButtonVisual(component, onToggleAction)
          ComponentType.SMPS_24V -> SmpsVisual(component)
          ComponentType.INDUCTIVE_SENSOR, ComponentType.PHOTOELECTRIC_SENSOR -> SensorVisual(component, onToggleAction)
          ComponentType.PILOT_LIGHT -> PilotLightVisual(component)
          ComponentType.INDUSTRIAL_BUZZER -> BuzzerVisual(component)
          ComponentType.PLC_CONTROLLER -> PlcControllerVisual(component)
          ComponentType.THERMAL_OVERLOAD -> OverloadVisual(component, onToggleAction)
          else -> GenericComponentVisual(component)
        }
      }
    }

    // Render Pin Terminals overlaid at their exact relative coordinate offsets
    component.pins.forEach { pin ->
      val isPinSelected = pin.id == selectedPinId
      PinTerminalWidget(
        pin = pin,
        isSelected = isPinSelected,
        isShort = isShort,
        onClick = { onPinClick(pin) },
        modifier = Modifier.offset(x = (pin.relativeOffset.x - 12).dp, y = (pin.relativeOffset.y - 12).dp)
      )
    }

    // Short circuit spark blast overlay
    if (isShort) {
      Canvas(modifier = Modifier.fillMaxSize()) {
        val center = Offset(size.width / 2, size.height / 2)
        drawCircle(
          brush = Brush.radialGradient(
            colors = listOf(Color.White, FaultRed.copy(alpha = 0.7f), Color.Transparent),
            center = center,
            radius = size.width * 0.7f
          ),
          center = center,
          radius = size.width * 0.7f
        )
      }
    }
  }
}

@Composable
fun PinTerminalWidget(
  pin: Pin,
  isSelected: Boolean,
  isShort: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val pinColor = when {
    isShort -> FaultRed
    pin.isEnergized -> when (pin.voltageType) {
      VoltageType.AC_L1, VoltageType.AC_L2, VoltageType.AC_L3 -> VoltageAmber
      VoltageType.DC_POS -> WireDcPositiveRed
      VoltageType.AC_N, VoltageType.DC_NEG -> WireNeutralBlue
      VoltageType.PE -> WireEarthGround
      else -> ElectricCyan
    }
    isSelected -> ElectricCyan
    else -> TerminalBrass
  }

  Column(
    modifier = modifier.clickable { onClick() },
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Box(
      modifier = Modifier
        .size(24.dp)
        .shadow(if (isSelected || pin.isEnergized) 6.dp else 1.dp, CircleShape)
        .clip(CircleShape)
        .background(IndustrialSurface)
        .border(
          width = if (isSelected) 2.dp else 1.5.dp,
          color = pinColor,
          shape = CircleShape
        ),
      contentAlignment = Alignment.Center
    ) {
      // Inner screw slot
      Canvas(modifier = Modifier.size(14.dp)) {
        drawCircle(color = pinColor.copy(alpha = 0.25f))
        // Screw head cross slot
        drawLine(
          color = pinColor,
          start = Offset(4f, 4f),
          end = Offset(size.width - 4f, size.height - 4f),
          strokeWidth = 2f
        )
        drawLine(
          color = pinColor,
          start = Offset(size.width - 4f, 4f),
          end = Offset(4f, size.height - 4f),
          strokeWidth = 2f
        )
      }
    }

    Text(
      text = pin.label,
      color = if (pin.isEnergized) pinColor else TextMuted,
      fontSize = 8.5.sp,
      fontWeight = FontWeight.Bold,
      fontFamily = FontFamily.Monospace,
      maxLines = 1
    )
  }
}

// -------------------------------------------------------------------------
// Component Internal Visuals: Tactile 3D Aesthetics
// -------------------------------------------------------------------------

@Composable
private fun MotorVisual(component: CircuitComponent) {
  val infiniteTransition = rememberInfiniteTransition(label = "motor_spin")
  val rotationSpeed = (component.motorRpm / 3000f).coerceIn(0f, 1f)
  val spinAngle by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(
        durationMillis = if (rotationSpeed > 0.05f) (1200 / (rotationSpeed * 5f).coerceAtLeast(1f)).toInt() else 100000,
        easing = LinearEasing
      ),
      repeatMode = RepeatMode.Restart
    ),
    label = "rotor_angle"
  )

  Column(
    modifier = Modifier.fillMaxSize(),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    // 3D Stator and Rotating Rotor Fan
    Box(
      modifier = Modifier
        .size(90.dp)
        .clip(CircleShape)
        .background(Color(0xFF1E293B))
        .border(3.dp, if (component.motorRpm > 10f) SafeGreen else IndustrialBorder, CircleShape),
      contentAlignment = Alignment.Center
    ) {
      // Rotor Blades
      Canvas(
        modifier = Modifier
          .fillMaxSize()
          .rotate(if (component.motorRpm > 10f) spinAngle else 0f)
      ) {
        val center = Offset(size.width / 2, size.height / 2)
        val numBlades = 6
        val radius = size.width / 2 - 8f

        for (i in 0 until numBlades) {
          val angle = (i * (2 * PI / numBlades)).toFloat()
          val x = center.x + radius * cos(angle)
          val y = center.y + radius * sin(angle)
          drawLine(
            color = if (component.motorRpm > 10f) ElectricCyan else Color(0xFF475569),
            start = center,
            end = Offset(x, y),
            strokeWidth = 4f
          )
        }
        drawCircle(
          color = Color(0xFF0F172A),
          radius = 16f,
          center = center
        )
      }

      // Motor Mode Center Badge
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
          text = component.motorMode,
          color = when (component.motorMode) {
            "DELTA" -> VoltageAmber
            "STAR" -> SafeGreen
            else -> TextMuted
          },
          fontSize = 11.sp,
          fontWeight = FontWeight.Black
        )
        Text(
          text = "${component.motorRpm.toInt()} RPM",
          color = TextPrimary,
          fontSize = 9.sp,
          fontFamily = FontFamily.Monospace
        )
      }
    }
  }
}

@Composable
private fun ContactorVisual(component: CircuitComponent, onToggle: () -> Unit) {
  val isEnergized = component.isEnergized

  Column(
    modifier = Modifier.fillMaxSize(),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    // Plunger Armature (Pulls down when energized)
    Box(
      modifier = Modifier
        .width(70.dp)
        .height(34.dp)
        .clip(RoundedCornerShape(4.dp))
        .background(if (isEnergized) Color(0xFF1E3A8A) else Color(0xFF1E293B))
        .border(1.dp, if (isEnergized) ElectricCyan else IndustrialBorder, RoundedCornerShape(4.dp)),
      contentAlignment = Alignment.Center
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Box(
          modifier = Modifier
            .size(10.dp)
            .clip(CircleShape)
            .background(if (isEnergized) VoltageAmber else Color(0xFF475569))
        )
        Text(
          text = if (isEnergized) "PULLED IN" else "RELEASED",
          color = if (isEnergized) TextPrimary else TextMuted,
          fontSize = 8.sp,
          fontWeight = FontWeight.Bold
        )
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    Text(
      text = "Coil: 230V AC",
      color = TextMuted,
      fontSize = 8.sp,
      fontFamily = FontFamily.Monospace
    )
  }
}

@Composable
private fun TimerVisual(component: CircuitComponent) {
  val progress = (component.timerElapsedSec / component.timerSetSec).coerceIn(0f, 1f)

  Column(
    modifier = Modifier.fillMaxSize(),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .size(60.dp)
        .clip(CircleShape)
        .background(Color(0xFF0F172A))
        .border(2.dp, if (component.isEnergized) VoltageAmber else IndustrialBorder, CircleShape),
      contentAlignment = Alignment.Center
    ) {
      Canvas(modifier = Modifier.fillMaxSize()) {
        drawArc(
          color = VoltageAmber,
          startAngle = -90f,
          sweepAngle = progress * 360f,
          useCenter = false,
          style = Stroke(width = 6f)
        )
      }

      Text(
        text = String.format("%.1fs", component.timerElapsedSec),
        color = if (component.timerElapsedSec >= component.timerSetSec) SafeGreen else TextPrimary,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Monospace
      )
    }

    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = "Preset: ${component.timerSetSec.toInt()}s",
      color = TextMuted,
      fontSize = 8.sp
    )
  }
}

@Composable
private fun RelayVisual(component: CircuitComponent) {
  val isEnergized = component.isEnergized

  Column(
    modifier = Modifier.fillMaxSize(),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    // Transparent casing with copper coil inside
    Box(
      modifier = Modifier
        .width(60.dp)
        .height(65.dp)
        .clip(RoundedCornerShape(6.dp))
        .background(Color(0x3300E5FF))
        .border(1.5.dp, if (isEnergized) VoltageAmber else IndustrialBorder, RoundedCornerShape(6.dp)),
      contentAlignment = Alignment.Center
    ) {
      Canvas(modifier = Modifier.fillMaxSize()) {
        // Draw coil copper windings
        val windingColor = if (isEnergized) VoltageAmber else Color(0xFFB45309)
        for (y in 15..50 step 6) {
          drawLine(
            color = windingColor,
            start = Offset(12f, y.toFloat()),
            end = Offset(size.width - 12f, y.toFloat()),
            strokeWidth = 3f
          )
        }
      }

      Box(
        modifier = Modifier
          .size(10.dp)
          .clip(CircleShape)
          .background(if (isEnergized) VoltageAmber else Color.Transparent)
      )
    }
    Spacer(modifier = Modifier.height(2.dp))
    Text(
      text = if (isEnergized) "CONTACTS NO" else "CONTACTS NC",
      color = if (isEnergized) SafeGreen else TextMuted,
      fontSize = 7.5.sp,
      fontWeight = FontWeight.Bold
    )
  }
}

@Composable
private fun BreakerVisual(component: CircuitComponent, onToggle: () -> Unit) {
  val isClosed = component.isClosed && !component.isTripped

  Column(
    modifier = Modifier
      .fillMaxSize()
      .clickable { onToggle() },
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    // Lever Handle
    Box(
      modifier = Modifier
        .width(36.dp)
        .height(48.dp)
        .clip(RoundedCornerShape(4.dp))
        .background(Color(0xFF1E293B))
        .border(1.dp, IndustrialBorder, RoundedCornerShape(4.dp)),
      contentAlignment = if (isClosed) Alignment.TopCenter else Alignment.BottomCenter
    ) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(22.dp)
          .clip(RoundedCornerShape(3.dp))
          .background(if (isClosed) SafeGreen else FaultRed)
          .border(1.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(3.dp)),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = if (isClosed) "I" else "O",
          color = Color.White,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold
        )
      }
    }

    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = if (isClosed) "CLOSED (ON)" else "OPEN (TRIPPED)",
      color = if (isClosed) SafeGreen else FaultRed,
      fontSize = 8.sp,
      fontWeight = FontWeight.Bold
    )
  }
}

@Composable
private fun PushButtonVisual(component: CircuitComponent, onToggle: () -> Unit) {
  val isStart = component.type == ComponentType.PUSH_BUTTON_START
  val isStop = component.type == ComponentType.PUSH_BUTTON_STOP
  val isEStop = component.type == ComponentType.EMERGENCY_STOP

  val baseColor = when {
    isStart -> SafeGreen
    isStop -> FaultRed
    isEStop -> FaultRed
    else -> VoltageAmber
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .clickable { onToggle() },
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .size(if (isEStop) 55.dp else 45.dp)
        .shadow(6.dp, CircleShape)
        .clip(CircleShape)
        .background(baseColor)
        .border(2.5.dp, Color.White.copy(alpha = 0.4f), CircleShape),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = when {
          isStart -> "START"
          isStop -> "STOP"
          isEStop -> "E-STOP"
          else -> "PB"
        },
        color = Color.White,
        fontSize = if (isEStop) 8.sp else 9.sp,
        fontWeight = FontWeight.Black
      )
    }

    Spacer(modifier = Modifier.height(3.dp))
    Text(
      text = if (component.isClosed) "PRESSED" else "RESTING",
      color = if (component.isClosed) ElectricCyan else TextMuted,
      fontSize = 7.5.sp,
      fontFamily = FontFamily.Monospace
    )
  }
}

@Composable
private fun SmpsVisual(component: CircuitComponent) {
  val isPowered = component.isEnergized

  Column(
    modifier = Modifier.fillMaxSize(),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth(0.85f)
        .height(60.dp)
        .clip(RoundedCornerShape(4.dp))
        .background(Color(0xFF1E293B))
        .border(1.dp, IndustrialBorder, RoundedCornerShape(4.dp)),
      contentAlignment = Alignment.Center
    ) {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .clip(CircleShape)
              .background(if (isPowered) SafeGreen else Color(0xFF475569))
          )
          Text(
            text = "DC OK",
            color = if (isPowered) SafeGreen else TextMuted,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold
          )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = if (isPowered) "24.0 VDC | 5.0A" else "OFFLINE",
          color = if (isPowered) TextPrimary else TextMuted,
          fontSize = 8.sp,
          fontFamily = FontFamily.Monospace
        )
      }
    }
  }
}

@Composable
private fun SensorVisual(component: CircuitComponent, onToggle: () -> Unit) {
  val isActive = component.sensorActive

  Column(
    modifier = Modifier
      .fillMaxSize()
      .clickable { onToggle() },
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    // Threaded barrel / optic eye
    Box(
      modifier = Modifier
        .width(55.dp)
        .height(32.dp)
        .clip(RoundedCornerShape(4.dp))
        .background(Color(0xFF334155))
        .border(1.dp, if (isActive) VoltageAmber else IndustrialBorder, RoundedCornerShape(4.dp)),
      contentAlignment = Alignment.Center
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Box(
          modifier = Modifier
            .size(10.dp)
            .clip(CircleShape)
            .background(if (isActive) VoltageAmber else Color(0xFF64748B))
        )
        Text(
          text = if (isActive) "DETECT" else "IDLE",
          color = if (isActive) VoltageAmber else TextMuted,
          fontSize = 8.sp,
          fontWeight = FontWeight.Bold
        )
      }
    }

    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = "Tap to Toggle Target",
      color = ElectricCyan,
      fontSize = 7.5.sp
    )
  }
}

@Composable
private fun PilotLightVisual(component: CircuitComponent) {
  val isLit = component.isEnergized
  val lampColor = if (component.tag.contains("TRIP", ignoreCase = true) || component.tag.contains("RED", ignoreCase = true)) {
    FaultRed
  } else {
    SafeGreen
  }

  Column(
    modifier = Modifier.fillMaxSize(),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .size(44.dp)
        .shadow(if (isLit) 12.dp else 2.dp, CircleShape, ambientColor = lampColor, spotColor = lampColor)
        .clip(CircleShape)
        .background(if (isLit) lampColor else Color(0xFF1E293B))
        .border(3.dp, Color(0xFF475569), CircleShape),
      contentAlignment = Alignment.Center
    ) {
      if (isLit) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          drawCircle(
            brush = Brush.radialGradient(
              listOf(Color.White, lampColor.copy(alpha = 0.8f), Color.Transparent),
              center = center,
              radius = size.width / 2
            )
          )
        }
      }
    }
  }
}

@Composable
private fun BuzzerVisual(component: CircuitComponent) {
  val isSounding = component.isEnergized

  Column(
    modifier = Modifier.fillMaxSize(),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Icon(
      imageVector = if (isSounding) Icons.Default.Campaign else Icons.Default.VolumeOff,
      contentDescription = "Buzzer",
      tint = if (isSounding) FaultRed else TextMuted,
      modifier = Modifier.size(36.dp)
    )
    Text(
      text = if (isSounding) "ALARM ON" else "SILENT",
      color = if (isSounding) FaultRed else TextMuted,
      fontSize = 8.sp,
      fontWeight = FontWeight.Bold
    )
  }
}

@Composable
private fun PlcControllerVisual(component: CircuitComponent) {
  val isEnergized = component.isEnergized

  Column(
    modifier = Modifier.fillMaxSize(),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .fillMaxWidth(0.92f)
        .height(95.dp)
        .clip(RoundedCornerShape(6.dp))
        .background(Color(0xFF0F172A))
        .border(1.dp, if (isEnergized) ElectricCyan else IndustrialBorder, RoundedCornerShape(6.dp))
        .padding(6.dp)
    ) {
      Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("S7-1200 CPU", color = ElectricCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
          Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            PlcStatusDot("RUN", isEnergized, SafeGreen)
            PlcStatusDot("ERR", false, FaultRed)
          }
        }

        // Input LED dots row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceEvenly
        ) {
          listOf("I0", "I1", "I2", "I3").forEach { label ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Box(
                modifier = Modifier
                  .size(6.dp)
                  .clip(CircleShape)
                  .background(if (isEnergized) SafeGreen.copy(alpha = 0.8f) else Color(0xFF334155))
              )
              Text(label, color = TextMuted, fontSize = 7.sp)
            }
          }
        }

        // Output LED dots row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceEvenly
        ) {
          listOf("Q0", "Q1", "Q2", "Q3").forEach { label ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Box(
                modifier = Modifier
                  .size(6.dp)
                  .clip(CircleShape)
                  .background(if (isEnergized) VoltageAmber else Color(0xFF334155))
              )
              Text(label, color = TextMuted, fontSize = 7.sp)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PlcStatusDot(label: String, isActive: Boolean, activeColor: Color) {
  Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
    Box(
      modifier = Modifier
        .size(5.dp)
        .clip(CircleShape)
        .background(if (isActive) activeColor else Color(0xFF475569))
    )
    Text(label, color = TextMuted, fontSize = 7.sp)
  }
}

@Composable
private fun OverloadVisual(component: CircuitComponent, onToggle: () -> Unit) {
  val isTripped = component.isTripped

  Column(
    modifier = Modifier.fillMaxSize(),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Reset button
      Box(
        modifier = Modifier
          .size(24.dp)
          .clip(CircleShape)
          .background(ElectricBlue)
          .clickable { onToggle() },
        contentAlignment = Alignment.Center
      ) {
        Text("R", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
      }

      // Test trip button
      Box(
        modifier = Modifier
          .size(24.dp)
          .clip(CircleShape)
          .background(FaultRed)
          .clickable { onToggle() },
        contentAlignment = Alignment.Center
      ) {
        Text("T", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
      }
    }

    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = if (isTripped) "OVERLOAD TRIPPED!" else "NORMAL RUN",
      color = if (isTripped) FaultRed else SafeGreen,
      fontSize = 8.sp,
      fontWeight = FontWeight.Bold
    )
  }
}

@Composable
private fun GenericComponentVisual(component: CircuitComponent) {
  Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
    Icon(
      imageVector = Icons.Default.PrecisionManufacturing,
      contentDescription = component.name,
      tint = if (component.isEnergized) ElectricCyan else TextMuted,
      modifier = Modifier.size(32.dp)
    )
  }
}
