package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun ConsoleDrawer(
  logs: List<DiagnosticLog>,
  simulationState: SimulationState,
  hasShortCircuit: Boolean,
  shortCircuitDesc: String,
  onClearLogs: () -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedFilter by remember { mutableStateOf("ALL") }
  val listState = rememberLazyListState()

  // Auto-scroll to bottom on new log
  LaunchedEffect(logs.size) {
    if (logs.isNotEmpty()) {
      listState.animateScrollToItem(logs.size - 1)
    }
  }

  val filteredLogs = remember(logs, selectedFilter) {
    when (selectedFilter) {
      "FAULTS" -> logs.filter { it.level == LogLevel.FAULT || it.level == LogLevel.WARN }
      "SUCCESS" -> logs.filter { it.level == LogLevel.SUCCESS }
      else -> logs
    }
  }

  Surface(
    modifier = modifier
      .fillMaxWidth()
      .heightIn(max = 280.dp),
    color = IndustrialSurface,
    tonalElevation = 8.dp,
    shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
    border = androidx.compose.foundation.BorderStroke(1.dp, IndustrialBorder)
  ) {
    Column(modifier = Modifier.fillMaxSize()) {
      // Header Bar
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(IndustrialSurfaceVariant)
          .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Icon(
            imageVector = Icons.Default.Terminal,
            contentDescription = "Console",
            tint = ElectricCyan,
            modifier = Modifier.size(18.dp)
          )
          Text(
            text = "REAL-TIME DIAGNOSTIC CONSOLE",
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )

          // State chip
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(
                when (simulationState) {
                  SimulationState.SHORT_CIRCUIT_TRIPPED -> FaultRed.copy(alpha = 0.2f)
                  SimulationState.RUNNING -> SafeGreen.copy(alpha = 0.2f)
                  else -> Color(0xFF334155)
                }
              )
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = when (simulationState) {
                SimulationState.SHORT_CIRCUIT_TRIPPED -> "SHORT CIRCUIT!"
                SimulationState.RUNNING -> "ENERGIZED"
                else -> "STANDBY"
              },
              color = when (simulationState) {
                SimulationState.SHORT_CIRCUIT_TRIPPED -> FaultRed
                SimulationState.RUNNING -> SafeGreen
                else -> TextMuted
              },
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          IconButton(
            onClick = onClearLogs,
            modifier = Modifier.size(28.dp)
          ) {
            Icon(
              imageVector = Icons.Default.DeleteSweep,
              contentDescription = "Clear",
              tint = TextMuted,
              modifier = Modifier.size(16.dp)
            )
          }
        }
      }

      // Filter Chips Row
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        listOf("ALL", "FAULTS", "SUCCESS").forEach { filter ->
          FilterChip(
            selected = selectedFilter == filter,
            onClick = { selectedFilter = filter },
            label = { Text(filter, fontSize = 10.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = ElectricCyan.copy(alpha = 0.2f),
              selectedLabelColor = ElectricCyan
            ),
            modifier = Modifier.height(28.dp)
          )
        }
      }

      // Active Short Circuit Banner
      if (hasShortCircuit) {
        Surface(
          color = FaultRed.copy(alpha = 0.15f),
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(6.dp))
            .border(1.dp, FaultRed, RoundedCornerShape(6.dp))
        ) {
          Row(
            modifier = Modifier.padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Icon(Icons.Default.FlashOn, contentDescription = "Short", tint = FaultRed, modifier = Modifier.size(20.dp))
            Column {
              Text("CIRCUIT TRIP: SHORT-CIRCUIT DETECTED", color = FaultRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
              Text(shortCircuitDesc, color = TextPrimary, fontSize = 10.sp)
            }
          }
        }
      }

      // Log Entries List
      LazyColumn(
        state = listState,
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f)
          .padding(horizontal = 12.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        if (filteredLogs.isEmpty()) {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "Console ready. Waiting for circuit power and switching events...",
                color = TextMuted,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }
        } else {
          items(filteredLogs) { log ->
            LogItemView(log)
          }
        }
      }
    }
  }
}

@Composable
private fun LogItemView(log: DiagnosticLog) {
  val levelColor = when (log.level) {
    LogLevel.FAULT -> FaultRed
    LogLevel.WARN -> VoltageAmber
    LogLevel.SUCCESS -> SafeGreen
    LogLevel.INFO -> ElectricCyan
  }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(4.dp))
      .background(IndustrialCardBg)
      .border(0.5.dp, IndustrialBorder, RoundedCornerShape(4.dp))
      .padding(6.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
          text = log.timestamp,
          color = TextMuted,
          fontSize = 9.sp,
          fontFamily = FontFamily.Monospace
        )
        Text(
          text = "[${log.level.name}]",
          color = levelColor,
          fontSize = 9.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace
        )
        Text(
          text = log.tag,
          color = TextSecondary,
          fontSize = 9.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace
        )
      }
    }

    Spacer(modifier = Modifier.height(2.dp))
    Text(
      text = log.message,
      color = TextPrimary,
      fontSize = 10.sp,
      fontFamily = FontFamily.Monospace
    )

    if (log.remedy != null) {
      Spacer(modifier = Modifier.height(2.dp))
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(2.dp))
          .background(Color(0xFF1E293B))
          .padding(4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        Icon(Icons.Default.HelpOutline, contentDescription = "Remedy", tint = ElectricCyan, modifier = Modifier.size(12.dp))
        Text(
          text = "Remedy: ${log.remedy}",
          color = ElectricCyan,
          fontSize = 9.sp,
          fontFamily = FontFamily.Monospace
        )
      }
    }
  }
}
