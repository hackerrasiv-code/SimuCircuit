package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

enum class MeterMode(val label: String, val unit: String) {
  VAC("V~ (AC)", "V AC"),
  VDC("V⎓ (DC)", "V DC"),
  CONTINUITY("Ω / BEEP", "Ω"),
  AMPS("A~ (Current)", "A")
}

@Composable
fun MultimeterSheet(
  selectedPin: Pin?,
  selectedComponent: CircuitComponent?,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier
) {
  var mode by remember { mutableStateOf(MeterMode.VAC) }

  val measuredValue = remember(selectedPin, mode) {
    if (selectedPin == null) {
      "---.-"
    } else {
      when (mode) {
        MeterMode.VAC -> {
          if (selectedPin.voltageType in listOf(VoltageType.AC_L1, VoltageType.AC_L2, VoltageType.AC_L3, VoltageType.SIGNAL)) {
            String.format("%.1f", if (selectedPin.isEnergized) selectedPin.potentialVolts else 0f)
          } else {
            "0.0"
          }
        }
        MeterMode.VDC -> {
          if (selectedPin.voltageType in listOf(VoltageType.DC_POS, VoltageType.SIGNAL)) {
            String.format("%.2f", if (selectedPin.isEnergized) selectedPin.potentialVolts else 0f)
          } else {
            "0.00"
          }
        }
        MeterMode.CONTINUITY -> {
          if (selectedPin.voltageType == VoltageType.AC_N || selectedPin.voltageType == VoltageType.DC_NEG || selectedPin.voltageType == VoltageType.PE) {
            "0.2" // Beep! Direct path
          } else if (selectedPin.isEnergized) {
            "34.8"
          } else {
            "O.L" // Open Loop
          }
        }
        MeterMode.AMPS -> {
          if (selectedPin.isEnergized) "2.42" else "0.00"
        }
      }
    }
  }

  Surface(
    modifier = modifier
      .fillMaxWidth()
      .padding(12.dp),
    color = Color(0xFF1E293B),
    shape = RoundedCornerShape(16.dp),
    border = androidx.compose.foundation.BorderStroke(2.dp, VoltageAmber)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      // Top Bar with Meter Brand and Close
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(VoltageAmber)
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text("FLUKE-PRO 87V", color = IndustrialBg, fontSize = 10.sp, fontWeight = FontWeight.Black)
          }
          Text("TRUE RMS INDUSTRIAL MULTIMETER", color = TextMuted, fontSize = 9.sp)
        }

        IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
          Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // High-Contrast Digital LCD Display
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .background(Color(0xFF0F172A))
          .border(1.5.dp, IndustrialBorder, RoundedCornerShape(8.dp))
          .padding(12.dp)
      ) {
        Column {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text("AUTO RANGE", color = SafeGreen, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
            Text(mode.unit, color = VoltageAmber, fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
          }

          Spacer(modifier = Modifier.height(4.dp))

          // Big 7-Segment Value
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.Bottom
          ) {
            Text(
              text = measuredValue,
              color = if (measuredValue == "O.L") FaultRed else ElectricCyan,
              fontSize = 32.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace,
              letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = mode.unit.split(" ").last(),
              color = TextPrimary,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(bottom = 4.dp)
            )
          }

          Spacer(modifier = Modifier.height(4.dp))

          // Probe Connection Information
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            val probeInfo = if (selectedPin != null && selectedComponent != null) {
              "Probe on ${selectedComponent.tag} : Pin [${selectedPin.label}]"
            } else {
              "Tap any terminal pin to take reading"
            }
            Text(probeInfo, color = TextSecondary, fontSize = 10.sp)
            if (mode == MeterMode.CONTINUITY && (measuredValue != "O.L" && measuredValue != "---.-")) {
              Text("(( BEEP ))", color = SafeGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Rotary Function Selector Buttons
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        MeterMode.values().forEach { m ->
          val isSelected = mode == m
          Button(
            onClick = { mode = m },
            modifier = Modifier
              .weight(1f)
              .height(36.dp),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(
              containerColor = if (isSelected) VoltageAmber else IndustrialSurface,
              contentColor = if (isSelected) IndustrialBg else TextPrimary
            ),
            contentPadding = PaddingValues(horizontal = 4.dp)
          ) {
            Text(m.label, fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
          }
        }
      }
    }
  }
}
