package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ComponentCategory
import com.example.model.ComponentType
import com.example.ui.theme.*

@Composable
fun PaletteDialog(
  onSelectType: (ComponentType) -> Unit,
  onDismiss: () -> Unit
) {
  var selectedCategory by remember { mutableStateOf<ComponentCategory?>(null) }

  val filteredTypes = remember(selectedCategory) {
    if (selectedCategory == null) {
      ComponentType.values().toList()
    } else {
      ComponentType.values().filter { it.category == selectedCategory }
    }
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    modifier = Modifier
      .fillMaxWidth(0.95f)
      .fillMaxHeight(0.85f),
    title = {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Icon(Icons.Default.AddBox, contentDescription = null, tint = ElectricCyan)
          Text("COMPONENT CATALOG", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        }
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
        }
      }
    },
    text = {
      Column(modifier = Modifier.fillMaxSize()) {
        // Category Filter Chips Row
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          FilterChip(
            selected = selectedCategory == null,
            onClick = { selectedCategory = null },
            label = { Text("All", fontSize = 9.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = ElectricCyan.copy(alpha = 0.2f),
              selectedLabelColor = ElectricCyan
            ),
            modifier = Modifier.height(26.dp)
          )
          ComponentCategory.values().take(3).forEach { cat ->
            FilterChip(
              selected = selectedCategory == cat,
              onClick = { selectedCategory = cat },
              label = { Text(cat.title.split(" ").first(), fontSize = 9.sp) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = ElectricCyan.copy(alpha = 0.2f),
                selectedLabelColor = ElectricCyan
              ),
              modifier = Modifier.height(26.dp)
            )
          }
        }

        // Components List
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          items(filteredTypes) { type ->
            ComponentTypeRow(type = type, onClick = { onSelectType(type) })
          }
        }
      }
    },
    confirmButton = {},
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel", color = TextMuted)
      }
    },
    containerColor = IndustrialSurface
  )
}

@Composable
private fun ComponentTypeRow(
  type: ComponentType,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(8.dp))
      .background(IndustrialCardBg)
      .border(1.dp, IndustrialBorder, RoundedCornerShape(8.dp))
      .clickable { onClick() }
      .padding(10.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      Box(
        modifier = Modifier
          .size(36.dp)
          .clip(RoundedCornerShape(6.dp))
          .background(Color(0xFF1E293B)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = when (type.category) {
            ComponentCategory.POWER_SUPPLY -> Icons.Default.Bolt
            ComponentCategory.SWITCHING -> Icons.Default.Tune
            ComponentCategory.ACTUATORS -> Icons.Default.RotateRight
            ComponentCategory.CONTROLS -> Icons.Default.RadioButtonChecked
            ComponentCategory.SENSORS -> Icons.Default.Sensors
            ComponentCategory.AUTOMATION -> Icons.Default.DeveloperBoard
          },
          contentDescription = null,
          tint = ElectricCyan,
          modifier = Modifier.size(20.dp)
        )
      }

      Column {
        Text(type.defaultName, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text("${type.category.title} • Tag: ${type.defaultTag}", color = TextMuted, fontSize = 9.sp)
      }
    }

    Icon(Icons.Default.AddCircleOutline, contentDescription = "Add", tint = ElectricCyan, modifier = Modifier.size(20.dp))
  }
}
