package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun PlcLadderDialog(
  program: PlcProgram,
  onDismiss: () -> Unit,
  onAddRung: () -> Unit,
  onToggleContact: (Int, Int) -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    modifier = Modifier
      .fillMaxWidth(0.95f)
      .fillMaxHeight(0.85f),
    title = {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Icon(Icons.Default.DeveloperBoard, contentDescription = "PLC", tint = ElectricCyan)
          Column {
            Text("PLC LADDER LOGIC SIMULATOR", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text("IEC 61131-3 Ladder Diagram (LD) Engine", fontSize = 10.sp, color = TextMuted)
          }
        }
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
        }
      }
    },
    text = {
      Column(modifier = Modifier.fillMaxSize()) {
        // Status Bar
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(IndustrialSurfaceVariant)
            .padding(8.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Scan Cycle: 10ms | Logic Solver: Active", color = SafeGreen, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
          Button(
            onClick = onAddRung,
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
            modifier = Modifier.height(28.dp),
            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = IndustrialBg)
          ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Add Rung", fontSize = 10.sp, fontWeight = FontWeight.Bold)
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Ladder Diagram Area with Left and Right Power Rails
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .clip(RoundedCornerShape(8.dp))
            .background(IndustrialCardBg)
            .border(1.dp, IndustrialBorder, RoundedCornerShape(8.dp))
            .padding(8.dp)
        ) {
          // Power Rails Background
          Canvas(modifier = Modifier.fillMaxSize()) {
            // Left Rail (+24V Power)
            drawLine(
              color = ElectricCyan,
              start = Offset(12.dp.toPx(), 0f),
              end = Offset(12.dp.toPx(), size.height),
              strokeWidth = 6f
            )
            // Right Rail (0V Return)
            drawLine(
              color = WireNeutralBlue,
              start = Offset(size.width - 12.dp.toPx(), 0f),
              end = Offset(size.width - 12.dp.toPx(), size.height),
              strokeWidth = 6f
            )
          }

          // Rungs List
          LazyColumn(
            modifier = Modifier
              .fillMaxSize()
              .padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
          ) {
            itemsIndexed(program.rungs) { rIndex, rung ->
              PlcRungView(
                rung = rung,
                onInstructionClick = { instIndex -> onToggleContact(rIndex, instIndex) }
              )
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) {
        Text("Done", color = ElectricCyan)
      }
    },
    containerColor = IndustrialSurface
  )
}

@Composable
private fun PlcRungView(
  rung: PlcLadderRung,
  onInstructionClick: (Int) -> Unit
) {
  val isRungEnergized = rung.isRungActive

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(6.dp))
      .background(IndustrialSurface)
      .border(
        width = if (isRungEnergized) 1.5.dp else 1.dp,
        color = if (isRungEnergized) SafeGreen else IndustrialBorder,
        shape = RoundedCornerShape(6.dp)
      )
      .padding(8.dp)
  ) {
    // Rung Header / Comment
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "Rung ${rung.rungNumber}",
        color = if (isRungEnergized) SafeGreen else TextMuted,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Monospace
      )
      if (rung.comment.isNotEmpty()) {
        Text(
          text = rung.comment,
          color = TextMuted,
          fontSize = 9.sp
        )
      }
    }

    Spacer(modifier = Modifier.height(8.dp))

    // Rung Wire with Contacts and Coil
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      // Input instructions row
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        rung.instructions.forEachIndexed { index, inst ->
          PlcInstructionBlock(
            instruction = inst,
            onClick = { onInstructionClick(index) }
          )
          if (index < rung.instructions.size - 1) {
            Box(
              modifier = Modifier
                .width(16.dp)
                .height(3.dp)
                .background(if (inst.isEnergized) SafeGreen else IndustrialBorder)
            )
          }
        }
      }

      // Connecting wire across to output
      Box(
        modifier = Modifier
          .weight(1f)
          .height(3.dp)
          .background(if (isRungEnergized) SafeGreen else IndustrialBorder)
          .padding(horizontal = 4.dp)
      )

      // Output Coil
      rung.outputInstruction?.let { outInst ->
        PlcInstructionBlock(
          instruction = outInst,
          onClick = {}
        )
      }
    }
  }
}

@Composable
private fun PlcInstructionBlock(
  instruction: PlcInstruction,
  onClick: () -> Unit
) {
  val isEnergized = instruction.isEnergized
  val accentColor = if (isEnergized) SafeGreen else TextPrimary

  Column(
    modifier = Modifier
      .clip(RoundedCornerShape(4.dp))
      .background(if (isEnergized) SafeGreen.copy(alpha = 0.15f) else Color(0xFF1E293B))
      .border(1.dp, if (isEnergized) SafeGreen else IndustrialBorder, RoundedCornerShape(4.dp))
      .clickable { onClick() }
      .padding(horizontal = 8.dp, vertical = 6.dp),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Text(
      text = instruction.operand,
      color = accentColor,
      fontSize = 9.sp,
      fontWeight = FontWeight.Bold,
      fontFamily = FontFamily.Monospace
    )
    Spacer(modifier = Modifier.height(2.dp))
    Text(
      text = instruction.type.symbol,
      color = accentColor,
      fontSize = 12.sp,
      fontWeight = FontWeight.Black,
      fontFamily = FontFamily.Monospace
    )
  }
}
