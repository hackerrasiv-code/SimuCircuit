package com.example.ui.components

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TroubleshootingReport
import com.example.ui.theme.*

@Composable
fun TroubleshootingReportDialog(
  report: TroubleshootingReport,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val scrollState = rememberScrollState()

  AlertDialog(
    onDismissRequest = onDismiss,
    modifier = Modifier
      .fillMaxWidth(0.95f)
      .fillMaxHeight(0.85f),
    title = {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Icon(
            imageVector = if (report.isSuccessful) Icons.Default.CheckCircle else Icons.Default.Warning,
            contentDescription = null,
            tint = if (report.isSuccessful) SafeGreen else FaultRed
          )
          Column {
            Text("TROUBLESHOOTING REPORT", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Text(report.scenarioName, fontSize = 10.sp, color = TextMuted)
          }
        }
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
        }
      }
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(scrollState)
      ) {
        // Summary Performance Card
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(IndustrialCardBg)
            .border(1.dp, IndustrialBorder, RoundedCornerShape(8.dp))
            .padding(12.dp),
          horizontalArrangement = Arrangement.SpaceAround
        ) {
          MetricCol("INTEGRITY", "${report.scorePercent}%", if (report.scorePercent >= 80) SafeGreen else FaultRed)
          MetricCol("WIRES", "${report.totalWiresConnected}", ElectricCyan)
          MetricCol("TIME", "${report.durationSeconds / 60}m ${report.durationSeconds % 60}s", VoltageAmber)
          MetricCol("RESULT", if (report.isSuccessful) "PASSED" else "FAULTS", if (report.isSuccessful) SafeGreen else FaultRed)
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Formatted Text Inspection Report
        Text(
          text = "INSPECTION AUDIT SUMMARY",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = TextSecondary
        )
        Spacer(modifier = Modifier.height(4.dp))

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF0F172A))
            .border(1.dp, IndustrialBorder, RoundedCornerShape(6.dp))
            .padding(10.dp)
        ) {
          Text(
            text = report.generateFormattedSummary(),
            color = TextPrimary,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            lineHeight = 14.sp
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          shareReport(context, report)
        },
        colors = ButtonDefaults.buttonColors(
          containerColor = ElectricCyan,
          contentColor = IndustrialBg
        )
      ) {
        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Export / Share Report", fontWeight = FontWeight.Bold, fontSize = 11.sp)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Close", color = TextMuted)
      }
    },
    containerColor = IndustrialSurface
  )
}

@Composable
private fun MetricCol(label: String, value: String, valueColor: Color) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(label, color = TextMuted, fontSize = 9.sp)
    Spacer(modifier = Modifier.height(2.dp))
    Text(value, color = valueColor, fontSize = 14.sp, fontWeight = FontWeight.Black)
  }
}

private fun shareReport(context: Context, report: TroubleshootingReport) {
  val intent = Intent(Intent.ACTION_SEND).apply {
    type = "text/plain"
    putExtra(Intent.EXTRA_SUBJECT, "SimuCircuit Inspection Report - ${report.scenarioName}")
    putExtra(Intent.EXTRA_TEXT, report.generateFormattedSummary())
  }
  context.startActivity(Intent.createChooser(intent, "Export Troubleshooting Report"))
}
