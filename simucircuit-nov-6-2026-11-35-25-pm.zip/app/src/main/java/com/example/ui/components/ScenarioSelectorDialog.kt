package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.scenarios.CircuitScenario
import com.example.scenarios.ScenarioRepository
import com.example.ui.theme.*

@Composable
fun ScenarioSelectorDialog(
  currentScenarioId: String,
  onSelectScenario: (CircuitScenario) -> Unit,
  onDismiss: () -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    modifier = Modifier
      .fillMaxWidth(0.95f)
      .fillMaxHeight(0.85f),
    title = {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Icon(Icons.Default.School, contentDescription = null, tint = VoltageAmber)
          Text("TRAINING LAB SCENARIOS", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        }
        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
        }
      }
    },
    text = {
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        items(ScenarioRepository.scenarios) { scenario ->
          val isSelected = scenario.id == currentScenarioId

          Surface(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .clickable { onSelectScenario(scenario) },
            color = if (isSelected) IndustrialSurfaceVariant else IndustrialCardBg,
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(
              width = if (isSelected) 1.5.dp else 1.dp,
              color = if (isSelected) ElectricCyan else IndustrialBorder
            )
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(scenario.title, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                      when (scenario.difficulty) {
                        "Beginner" -> SafeGreen.copy(alpha = 0.2f)
                        "Intermediate" -> VoltageAmber.copy(alpha = 0.2f)
                        "Advanced" -> FaultRed.copy(alpha = 0.2f)
                        else -> ElectricCyan.copy(alpha = 0.2f)
                      }
                    )
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = scenario.difficulty,
                    color = when (scenario.difficulty) {
                      "Beginner" -> SafeGreen
                      "Intermediate" -> VoltageAmber
                      "Advanced" -> FaultRed
                      else -> ElectricCyan
                    },
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.Bold
                  )
                }
              }

              Spacer(modifier = Modifier.height(2.dp))
              Text(scenario.subtitle, color = ElectricCyan, fontSize = 10.sp)
              Spacer(modifier = Modifier.height(4.dp))
              Text(scenario.description, color = TextSecondary, fontSize = 9.sp, lineHeight = 13.sp)
            }
          }
        }
      }
    },
    confirmButton = {},
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel", color = TextMuted)
      }
    },
    containerColor = IndustrialSurface
  )
}
