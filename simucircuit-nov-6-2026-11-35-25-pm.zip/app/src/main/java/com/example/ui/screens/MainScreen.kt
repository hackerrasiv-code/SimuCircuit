package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.viewmodel.CircuitViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
  viewModel: CircuitViewModel,
  modifier: Modifier = Modifier
) {
  val uiState by viewModel.uiState.collectAsState()

  Scaffold(
    topBar = {
      IndustrialTopAppBar(
        scenarioTitle = uiState.currentScenario.title,
        isPowerOn = uiState.isPowerOn,
        hasShort = uiState.hasShortCircuit,
        isMultimeterActive = uiState.isMultimeterActive,
        isConsoleExpanded = uiState.isConsoleExpanded,
        onScenarioClick = { viewModel.showScenarioSelector(true) },
        onTogglePower = { viewModel.togglePower() },
        onToggleMultimeter = { viewModel.toggleMultimeter() },
        onShowPlc = { viewModel.showPlcDialog(true) },
        onShowReport = { viewModel.showReportDialog(true) },
        onToggleConsole = { viewModel.toggleConsole() },
        onReset = { viewModel.resetCurrentScenario() }
      )
    },
    floatingActionButton = {
      FloatingActionButton(
        onClick = { viewModel.showPalette(true) },
        containerColor = ElectricCyan,
        contentColor = IndustrialBg,
        shape = CircleShape,
        modifier = Modifier.padding(bottom = if (uiState.isConsoleExpanded) 190.dp else 16.dp)
      ) {
        Icon(Icons.Default.Add, contentDescription = "Add Component")
      }
    },
    containerColor = IndustrialBg
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
    ) {
      // 1. The Interactive Canvas with Animated Pathways & 3D Components
      AnimatedCircuitCanvas(
        components = uiState.components,
        wires = uiState.wires,
        selectedComponentId = uiState.selectedComponentId,
        selectedPin = uiState.selectedPin,
        wiringDragCurrentPos = null,
        currentWireColor = uiState.currentWireColor,
        isMultimeterActive = uiState.isMultimeterActive,
        onComponentSelect = { comp ->
          viewModel.toggleComponentInteraction(comp.id)
        },
        onComponentMove = { id, x, y ->
          viewModel.moveComponent(id, x, y)
        },
        onPinClick = { comp, pin ->
          viewModel.onPinClicked(comp, pin)
        },
        onWireClick = { wire ->
          viewModel.removeWire(wire.id)
        },
        onCanvasTap = {
          // Deselect
        }
      )

      // 2. Wire Color & Terminal Selector Strip (Top Overlay)
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .align(Alignment.TopCenter)
      ) {
        WireToolBar(
          selectedColor = uiState.currentWireColor,
          selectedPin = uiState.selectedPin,
          onSelectColor = { viewModel.setWireColor(it) },
          onClearWires = { viewModel.clearAllWires() }
        )
      }

      // 3. Digital Multimeter HUD Overlay (if active)
      if (uiState.isMultimeterActive) {
        val selComp = uiState.components.find { it.id == uiState.selectedPin?.componentId }
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .align(Alignment.TopEnd)
            .padding(top = 50.dp, end = 8.dp)
            .widthIn(max = 380.dp)
        ) {
          MultimeterSheet(
            selectedPin = uiState.selectedPin,
            selectedComponent = selComp,
            onDismiss = { viewModel.toggleMultimeter() }
          )
        }
      }

      // 4. Real-time Debugging Console (Bottom Drawer)
      AnimatedVisibility(
        visible = uiState.isConsoleExpanded,
        enter = slideInVertically { it },
        exit = slideOutVertically { it },
        modifier = Modifier.align(Alignment.BottomCenter)
      ) {
        ConsoleDrawer(
          logs = uiState.diagnosticLogs,
          simulationState = uiState.simulationState,
          hasShortCircuit = uiState.hasShortCircuit,
          shortCircuitDesc = uiState.shortCircuitDescription,
          onClearLogs = { viewModel.clearLogs() }
        )
      }
    }
  }

  // Dialogs
  if (uiState.isPlcDialogVisible) {
    PlcLadderDialog(
      program = uiState.plcProgram,
      onDismiss = { viewModel.showPlcDialog(false) },
      onAddRung = { viewModel.addPlcRung() },
      onToggleContact = { r, i -> viewModel.togglePlcContact(r, i) }
    )
  }

  if (uiState.isReportDialogVisible && uiState.generatedReport != null) {
    TroubleshootingReportDialog(
      report = uiState.generatedReport!!,
      onDismiss = { viewModel.showReportDialog(false) }
    )
  }

  if (uiState.isScenarioSelectorVisible) {
    ScenarioSelectorDialog(
      currentScenarioId = uiState.currentScenario.id,
      onSelectScenario = { viewModel.loadScenario(it) },
      onDismiss = { viewModel.showScenarioSelector(false) }
    )
  }

  if (uiState.isPaletteVisible) {
    PaletteDialog(
      onSelectType = { viewModel.addComponent(it) },
      onDismiss = { viewModel.showPalette(false) }
    )
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IndustrialTopAppBar(
  scenarioTitle: String,
  isPowerOn: Boolean,
  hasShort: Boolean,
  isMultimeterActive: Boolean,
  isConsoleExpanded: Boolean,
  onScenarioClick: () -> Unit,
  onTogglePower: () -> Unit,
  onToggleMultimeter: () -> Unit,
  onShowPlc: () -> Unit,
  onShowReport: () -> Unit,
  onToggleConsole: () -> Unit,
  onReset: () -> Unit
) {
  TopAppBar(
    title = {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.clickable { onScenarioClick() }
      ) {
        Icon(
          imageVector = Icons.Default.Bolt,
          contentDescription = "SimuCircuit",
          tint = if (hasShort) FaultRed else if (isPowerOn) ElectricCyan else TextMuted,
          modifier = Modifier.size(22.dp)
        )
        Column {
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("SimuCircuit", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black)
            Box(
              modifier = Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(if (hasShort) FaultRed else if (isPowerOn) SafeGreen else Color(0xFF475569))
            )
          }
          Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(scenarioTitle, color = ElectricCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = ElectricCyan, modifier = Modifier.size(14.dp))
          }
        }
      }
    },
    actions = {
      // Master Power Supply Button
      IconButton(
        onClick = onTogglePower,
        modifier = Modifier
          .padding(end = 4.dp)
          .size(34.dp)
          .clip(CircleShape)
          .background(if (isPowerOn) SafeGreen.copy(alpha = 0.2f) else IndustrialSurfaceVariant)
          .border(1.dp, if (isPowerOn) SafeGreen else IndustrialBorder, CircleShape)
      ) {
        Icon(
          imageVector = Icons.Default.PowerSettingsNew,
          contentDescription = "Power",
          tint = if (isPowerOn) SafeGreen else TextMuted,
          modifier = Modifier.size(18.dp)
        )
      }

      // Multimeter Meter Probe Button
      IconButton(
        onClick = onToggleMultimeter,
        modifier = Modifier
          .padding(end = 4.dp)
          .size(34.dp)
          .clip(CircleShape)
          .background(if (isMultimeterActive) VoltageAmber.copy(alpha = 0.25f) else IndustrialSurfaceVariant)
          .border(1.dp, if (isMultimeterActive) VoltageAmber else IndustrialBorder, CircleShape)
      ) {
        Icon(
          imageVector = Icons.Default.Speed,
          contentDescription = "Meter",
          tint = if (isMultimeterActive) VoltageAmber else TextPrimary,
          modifier = Modifier.size(18.dp)
        )
      }

      // PLC Ladder Logic Dialog Button
      IconButton(
        onClick = onShowPlc,
        modifier = Modifier.size(32.dp)
      ) {
        Icon(
          imageVector = Icons.Default.DeveloperBoard,
          contentDescription = "PLC",
          tint = ElectricCyan,
          modifier = Modifier.size(18.dp)
        )
      }

      // Export Inspection Report Button
      IconButton(
        onClick = onShowReport,
        modifier = Modifier.size(32.dp)
      ) {
        Icon(
          imageVector = Icons.Default.AssignmentTurnedIn,
          contentDescription = "Report",
          tint = SafeGreen,
          modifier = Modifier.size(18.dp)
        )
      }

      // Toggle Console Drawer Button
      IconButton(
        onClick = onToggleConsole,
        modifier = Modifier.size(32.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Terminal,
          contentDescription = "Console",
          tint = if (isConsoleExpanded) ElectricCyan else TextMuted,
          modifier = Modifier.size(18.dp)
        )
      }

      // Reset Scenario Button
      IconButton(
        onClick = onReset,
        modifier = Modifier.size(32.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Refresh,
          contentDescription = "Reset",
          tint = TextMuted,
          modifier = Modifier.size(18.dp)
        )
      }
    },
    colors = TopAppBarDefaults.topAppBarColors(
      containerColor = IndustrialSurface,
      titleContentColor = TextPrimary
    )
  )
}

@Composable
private fun WireToolBar(
  selectedColor: WireColor,
  selectedPin: Pin?,
  onSelectColor: (WireColor) -> Unit,
  onClearWires: () -> Unit
) {
  Surface(
    color = IndustrialSurface.copy(alpha = 0.95f),
    tonalElevation = 4.dp,
    border = androidx.compose.foundation.BorderStroke(0.5.dp, IndustrialBorder)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Text("Wire Standard:", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)

        WireColor.values().forEach { wc ->
          val isSel = selectedColor == wc
          Row(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(if (isSel) wc.color.copy(alpha = 0.25f) else Color.Transparent)
              .border(if (isSel) 1.5.dp else 0.5.dp, if (isSel) wc.color else IndustrialBorder, RoundedCornerShape(4.dp))
              .clickable { onSelectColor(wc) }
              .padding(horizontal = 6.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
          ) {
            Box(
              modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(wc.color)
            )
            Text(
              text = wc.displayName.split(" ").first(),
              color = if (isSel) TextPrimary else TextSecondary,
              fontSize = 8.5.sp,
              fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
            )
          }
        }

        Spacer(modifier = Modifier.width(8.dp))

        TextButton(
          onClick = onClearWires,
          contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
          modifier = Modifier.height(24.dp)
        ) {
          Text("Clear Wires", color = FaultRed, fontSize = 8.5.sp)
        }
      }

      // Wiring guidance banner if a pin is active
      if (selectedPin != null) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 2.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Icon(Icons.Default.Link, contentDescription = null, tint = ElectricCyan, modifier = Modifier.size(12.dp))
          Text(
            text = "Lead connected to [${selectedPin.label}]. Tap another terminal pin to complete connection.",
            color = ElectricCyan,
            fontSize = 9.5.sp,
            fontFamily = FontFamily.Monospace
          )
        }
      }
    }
  }
}
