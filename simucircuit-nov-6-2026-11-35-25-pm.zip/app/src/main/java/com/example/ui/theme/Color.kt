package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Industrial Electric Color Palette
val IndustrialBg = Color(0xFF090D14)
val IndustrialSurface = Color(0xFF111827)
val IndustrialSurfaceVariant = Color(0xFF1A2333)
val IndustrialCardBg = Color(0xFF141C2B)
val IndustrialBorder = Color(0xFF243247)
val IndustrialGridLine = Color(0xFF1E293B)
val IndustrialDinRail = Color(0xFF334155)

// Electrical Signal Colors
val ElectricCyan = Color(0xFF00E5FF)
val ElectricBlue = Color(0xFF0284C7)
val VoltageAmber = Color(0xFFFFB300)
val WarningOrange = Color(0xFFFF9100)
val FaultRed = Color(0xFFFF1744)
val ShortCircuitGlow = Color(0xFFFF5252)
val SafeGreen = Color(0xFF00E676)
val EarthGreenYellow = Color(0xFF76FF03)

// Wire Standard Phase Colors (IEC / Industrial Standard)
val WirePhase1Brown = Color(0xFF8D6E63) // L1
val WirePhase2Black = Color(0xFF37474F) // L2
val WirePhase3Grey = Color(0xFF78909C)  // L3
val WireNeutralBlue = Color(0xFF00B0FF) // Neutral
val WireEarthGround = Color(0xFF76FF03) // PE
val WireDcPositiveRed = Color(0xFFE53935) // +24V DC
val WireDcNegativeNavy = Color(0xFF1E88E5) // 0V DC
val WireControlPurple = Color(0xFFAB47BC) // Control signal

// Text / Contrast
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TerminalBrass = Color(0xFFFFD54F)
val TerminalGlow = Color(0xFF00E5FF)
