package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val IndustrialDarkColorScheme = darkColorScheme(
  primary = ElectricCyan,
  onPrimary = IndustrialBg,
  primaryContainer = IndustrialSurfaceVariant,
  onPrimaryContainer = ElectricCyan,
  secondary = VoltageAmber,
  onSecondary = IndustrialBg,
  secondaryContainer = IndustrialSurfaceVariant,
  onSecondaryContainer = VoltageAmber,
  tertiary = SafeGreen,
  onTertiary = IndustrialBg,
  background = IndustrialBg,
  onBackground = TextPrimary,
  surface = IndustrialSurface,
  onSurface = TextPrimary,
  surfaceVariant = IndustrialSurfaceVariant,
  onSurfaceVariant = TextSecondary,
  error = FaultRed,
  onError = TextPrimary,
  outline = IndustrialBorder
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Industrial circuit sim defaults to dark technical aesthetic
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = IndustrialDarkColorScheme
  val view = LocalView.current
  if (!view.isInEditMode) {
    SideEffect {
      val window = (view.context as Activity).window
      window.statusBarColor = IndustrialBg.toArgb()
      window.navigationBarColor = IndustrialBg.toArgb()
      WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
      WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
    }
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
