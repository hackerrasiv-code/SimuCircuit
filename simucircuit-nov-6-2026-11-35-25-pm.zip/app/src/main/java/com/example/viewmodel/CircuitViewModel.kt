package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.*
import com.example.scenarios.ComponentFactory
import com.example.scenarios.CircuitScenario
import com.example.scenarios.ScenarioRepository
import com.example.simulation.CircuitEngine
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class CircuitUiState(
  val currentScenario: CircuitScenario,
  val components: List<CircuitComponent> = emptyList(),
  val wires: List<Wire> = emptyList(),
  val plcProgram: PlcProgram = PlcProgram(),
  val simulationState: SimulationState = SimulationState.STANDBY,
  val isPowerOn: Boolean = true,
  val hasShortCircuit: Boolean = false,
  val shortCircuitDescription: String = "",
  val diagnosticLogs: List<DiagnosticLog> = emptyList(),
  val detectedIssues: List<DiagnosticIssue> = emptyList(),
  val selectedComponentId: String? = null,
  val selectedPin: Pin? = null,
  val currentWireColor: WireColor = WireColor.L1_BROWN,
  val isMultimeterActive: Boolean = false,
  val isConsoleExpanded: Boolean = true,
  val isPlcDialogVisible: Boolean = false,
  val isReportDialogVisible: Boolean = false,
  val isScenarioSelectorVisible: Boolean = false,
  val isPaletteVisible: Boolean = false,
  val sessionDurationSeconds: Long = 0,
  val generatedReport: TroubleshootingReport? = null
)

class CircuitViewModel(application: Application) : AndroidViewModel(application) {

  private val circuitEngine = CircuitEngine()
  private val initialScenario = ScenarioRepository.scenarios.first()

  private val _uiState = MutableStateFlow(
    CircuitUiState(
      currentScenario = initialScenario,
      components = initialScenario.components,
      wires = initialScenario.initialWires,
      plcProgram = initialScenario.initialPlcProgram
    )
  )
  val uiState: StateFlow<CircuitUiState> = _uiState.asStateFlow()

  private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
    val vibratorManager = application.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
    vibratorManager?.defaultVibrator
  } else {
    @Suppress("DEPRECATION")
    application.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
  }

  private var hadShortCircuitLastTick = false

  init {
    startSimulationLoop()
    startTimerLoop()
  }

  private fun startSimulationLoop() {
    viewModelScope.launch {
      val deltaSeconds = 0.05f // 20 FPS simulation cycle
      while (true) {
        delay(50)

        val state = _uiState.value
        if (!state.isPowerOn) continue

        val result = circuitEngine.simulate(
          components = state.components,
          wires = state.wires,
          deltaSeconds = deltaSeconds,
          plcProgram = state.plcProgram
        )

        // Haptic feedback on short circuit or faults
        if (result.hasShortCircuit && !hadShortCircuitLastTick) {
          triggerHaptic(isCritical = true)
        }
        hadShortCircuitLastTick = result.hasShortCircuit

        _uiState.update { curr ->
          val combinedLogs = if (result.diagnosticLogs.isNotEmpty()) {
            (curr.diagnosticLogs + result.diagnosticLogs).takeLast(100)
          } else {
            curr.diagnosticLogs
          }

          curr.copy(
            components = result.components,
            wires = result.wires,
            plcProgram = result.plcProgram,
            simulationState = result.simulationState,
            hasShortCircuit = result.hasShortCircuit,
            shortCircuitDescription = result.shortCircuitDescription,
            diagnosticLogs = combinedLogs,
            detectedIssues = result.detectedIssues
          )
        }
      }
    }
  }

  private fun startTimerLoop() {
    viewModelScope.launch {
      while (true) {
        delay(1000)
        _uiState.update { it.copy(sessionDurationSeconds = it.sessionDurationSeconds + 1) }
      }
    }
  }

  fun loadScenario(scenario: CircuitScenario) {
    _uiState.update {
      it.copy(
        currentScenario = scenario,
        components = scenario.components,
        wires = scenario.initialWires,
        plcProgram = scenario.initialPlcProgram,
        selectedComponentId = null,
        selectedPin = null,
        hasShortCircuit = false,
        shortCircuitDescription = "",
        isScenarioSelectorVisible = false,
        sessionDurationSeconds = 0
      )
    }
    logAction("SCENARIO", "Loaded scenario: ${scenario.title}")
  }

  fun togglePower() {
    val newPower = !_uiState.value.isPowerOn
    _uiState.update { it.copy(isPowerOn = newPower) }
    triggerHaptic(isCritical = false)
    logAction("POWER", if (newPower) "Master Power Supply ON (400V 3-Phase Bus active)" else "Master Power OFF")
  }

  fun onPinClicked(component: CircuitComponent, pin: Pin) {
    val currentSelected = _uiState.value.selectedPin

    if (currentSelected == null) {
      // First pin selection
      _uiState.update {
        it.copy(
          selectedPin = pin,
          selectedComponentId = component.id
        )
      }
      triggerHaptic(isCritical = false)
    } else {
      // Second pin selection -> create wire or cancel if clicked same
      if (currentSelected.componentId == component.id && currentSelected.id == pin.id) {
        // Deselect
        _uiState.update { it.copy(selectedPin = null) }
      } else {
        // Create Wire!
        val newWire = Wire(
          id = "w_${System.currentTimeMillis() % 100000}",
          fromComponentId = currentSelected.componentId,
          fromPinId = currentSelected.id,
          toComponentId = component.id,
          toPinId = pin.id,
          color = _uiState.value.currentWireColor
        )

        _uiState.update {
          it.copy(
            wires = it.wires + newWire,
            selectedPin = null
          )
        }
        triggerHaptic(isCritical = false)
        logAction("WIRING", "Connected wire from [${currentSelected.label}] to [${pin.label}]")
      }
    }
  }

  fun removeWire(wireId: String) {
    _uiState.update {
      it.copy(wires = it.wires.filterNot { w -> w.id == wireId })
    }
    logAction("WIRING", "Removed wire $wireId")
  }

  fun clearAllWires() {
    _uiState.update { it.copy(wires = emptyList(), selectedPin = null) }
    logAction("WIRING", "Cleared all circuit wires.")
  }

  fun resetCurrentScenario() {
    val scen = _uiState.value.currentScenario
    loadScenario(scen)
  }

  fun moveComponent(componentId: String, newX: Float, newY: Float) {
    _uiState.update { curr ->
      val updated = curr.components.map { comp ->
        if (comp.id == componentId) comp.copy(x = newX, y = newY) else comp
      }
      curr.copy(components = updated)
    }
  }

  fun toggleComponentInteraction(componentId: String) {
    _uiState.update { curr ->
      val updated = curr.components.map { comp ->
        if (comp.id == componentId) {
          when (comp.type) {
            ComponentType.CIRCUIT_BREAKER_3P, ComponentType.CIRCUIT_BREAKER_1P -> {
              comp.copy(isClosed = !comp.isClosed, isTripped = false)
            }
            ComponentType.PUSH_BUTTON_START -> {
              comp.copy(isClosed = !comp.isClosed)
            }
            ComponentType.PUSH_BUTTON_STOP, ComponentType.EMERGENCY_STOP -> {
              comp.copy(isClosed = !comp.isClosed)
            }
            ComponentType.INDUCTIVE_SENSOR, ComponentType.PHOTOELECTRIC_SENSOR, ComponentType.LIMIT_SWITCH -> {
              comp.copy(sensorActive = !comp.sensorActive)
            }
            ComponentType.THERMAL_OVERLOAD -> {
              comp.copy(isTripped = !comp.isTripped)
            }
            else -> comp
          }
        } else {
          comp
        }
      }
      curr.copy(components = updated)
    }
    triggerHaptic(isCritical = false)
  }

  fun addComponent(type: ComponentType) {
    val count = _uiState.value.components.count { it.type == type } + 1
    val newComp = ComponentFactory.createComponent(
      type = type,
      id = "c_${System.currentTimeMillis() % 10000}",
      tag = "${type.defaultTag}_$count",
      x = 80f + (count * 20f),
      y = 120f
    )
    _uiState.update {
      it.copy(
        components = it.components + newComp,
        isPaletteVisible = false
      )
    }
    logAction("PALETTE", "Added ${newComp.name} (${newComp.tag}) to canvas")
  }

  fun removeComponent(componentId: String) {
    _uiState.update { curr ->
      curr.copy(
        components = curr.components.filterNot { it.id == componentId },
        wires = curr.wires.filterNot { it.fromComponentId == componentId || it.toComponentId == componentId }
      )
    }
    logAction("PALETTE", "Removed component $componentId")
  }

  fun setWireColor(color: WireColor) {
    _uiState.update { it.copy(currentWireColor = color) }
  }

  fun toggleMultimeter() {
    _uiState.update { it.copy(isMultimeterActive = !it.isMultimeterActive) }
  }

  fun toggleConsole() {
    _uiState.update { it.copy(isConsoleExpanded = !it.isConsoleExpanded) }
  }

  fun showPlcDialog(show: Boolean) {
    _uiState.update { it.copy(isPlcDialogVisible = show) }
  }

  fun showScenarioSelector(show: Boolean) {
    _uiState.update { it.copy(isScenarioSelectorVisible = show) }
  }

  fun showPalette(show: Boolean) {
    _uiState.update { it.copy(isPaletteVisible = show) }
  }

  fun showReportDialog(show: Boolean) {
    if (show) {
      generateReport()
    }
    _uiState.update { it.copy(isReportDialogVisible = show) }
  }

  fun clearLogs() {
    _uiState.update { it.copy(diagnosticLogs = emptyList()) }
  }

  fun addPlcRung() {
    val currRungs = _uiState.value.plcProgram.rungs
    val newRung = PlcLadderRung(
      id = "rung_${currRungs.size}",
      rungNumber = currRungs.size,
      comment = "User Custom Logic",
      instructions = listOf(
        PlcInstruction("i_new", PlcInstructionType.CONTACT_NO, "I0.0")
      ),
      outputInstruction = PlcInstruction("q_new", PlcInstructionType.COIL_NORMAL, "Q0.0")
    )
    _uiState.update {
      it.copy(plcProgram = it.plcProgram.copy(rungs = currRungs + newRung))
    }
    logAction("PLC", "Added ladder rung ${currRungs.size}")
  }

  fun togglePlcContact(rungIndex: Int, instIndex: Int) {
    val rungs = _uiState.value.plcProgram.rungs.toMutableList()
    if (rungIndex in rungs.indices) {
      val rung = rungs[rungIndex]
      val insts = rung.instructions.toMutableList()
      if (instIndex in insts.indices) {
        val curr = insts[instIndex]
        val newType = if (curr.type == PlcInstructionType.CONTACT_NO) PlcInstructionType.CONTACT_NC else PlcInstructionType.CONTACT_NO
        insts[instIndex] = curr.copy(type = newType)
        rungs[rungIndex] = rung.copy(instructions = insts)
        _uiState.update { it.copy(plcProgram = it.plcProgram.copy(rungs = rungs)) }
      }
    }
  }

  private fun generateReport() {
    val state = _uiState.value
    val isSuccess = !state.hasShortCircuit && state.components.any { it.isEnergized }
    val score = when {
      state.hasShortCircuit -> 30
      state.detectedIssues.isNotEmpty() -> 70
      state.wires.size < 4 -> 50
      else -> 98
    }

    val report = TroubleshootingReport(
      scenarioName = state.currentScenario.title,
      timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date()),
      durationSeconds = state.sessionDurationSeconds,
      isSuccessful = isSuccess,
      totalWiresConnected = state.wires.size,
      totalComponentsActive = state.components.count { it.isEnergized },
      scorePercent = score,
      detectedIssues = state.detectedIssues,
      sequenceHistory = state.diagnosticLogs.takeLast(10).map { "[${it.level}] ${it.tag}: ${it.message}" }
    )

    _uiState.update { it.copy(generatedReport = report) }
  }

  private fun logAction(tag: String, message: String) {
    val log = DiagnosticLog(
      timestamp = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date()),
      level = LogLevel.INFO,
      tag = tag,
      message = message
    )
    _uiState.update { it.copy(diagnosticLogs = (it.diagnosticLogs + log).takeLast(100)) }
  }

  private fun triggerHaptic(isCritical: Boolean) {
    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val effect = if (isCritical) {
          VibrationEffect.createWaveform(longArrayOf(0, 100, 80, 150), -1)
        } else {
          VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE)
        }
        vibrator?.vibrate(effect)
      } else {
        @Suppress("DEPRECATION")
        vibrator?.vibrate(if (isCritical) 250 else 30)
      }
    } catch (_: Exception) {}
  }
}
