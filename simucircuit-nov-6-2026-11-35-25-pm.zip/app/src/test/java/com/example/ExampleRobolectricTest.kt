package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.*
import com.example.scenarios.ComponentFactory
import com.example.scenarios.ScenarioRepository
import com.example.simulation.CircuitEngine
import com.example.simulation.PlcEngine
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context matches SimuCircuit`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("SimuCircuit", appName)
  }

  @Test
  fun `test circuit engine detects short circuit between Phase and Neutral`() {
    val engine = CircuitEngine()
    val acPwr = ComponentFactory.createComponent(ComponentType.AC_SOURCE_3P, "pwr1", "AC", 0f, 0f)

    // Direct dead short wire from L1 to N
    val shortWire = Wire("w_short", "pwr1", "L1", "pwr1", "N", WireColor.L1_BROWN)

    val result = engine.simulate(
      components = listOf(acPwr),
      wires = listOf(shortWire),
      deltaSeconds = 0.05f,
      plcProgram = PlcProgram()
    )

    assertTrue("Engine must detect short circuit when Phase connects directly to Neutral", result.hasShortCircuit)
    assertEquals(SimulationState.SHORT_CIRCUIT_TRIPPED, result.simulationState)
  }

  @Test
  fun `test PLC ladder logic solves series contacts and coils`() {
    val plcEngine = PlcEngine()
    val program = PlcProgram(
      rungs = listOf(
        PlcLadderRung(
          id = "r0",
          rungNumber = 0,
          instructions = listOf(
            PlcInstruction("i0", PlcInstructionType.CONTACT_NO, "I0.0"),
            PlcInstruction("i1", PlcInstructionType.CONTACT_NC, "I0.1")
          ),
          outputInstruction = PlcInstruction("q0", PlcInstructionType.COIL_NORMAL, "Q0.0")
        )
      )
    )

    // Case 1: I0.0 is ON, I0.1 is OFF -> Q0.0 should be TRUE
    val (resultProg1, outputs1) = plcEngine.executeScanCycle(
      program = program,
      inputStates = mapOf("I0.0" to true, "I0.1" to false),
      deltaSeconds = 0.05f
    )
    assertTrue("Q0.0 must be energized when I0.0 is True and I0.1 is False", outputs1["Q0.0"] == true)
    assertTrue(resultProg1.rungs[0].isRungActive)

    // Case 2: Stop button pressed (I0.1 becomes TRUE -> NC opens) -> Q0.0 should be FALSE
    val (resultProg2, outputs2) = plcEngine.executeScanCycle(
      program = program,
      inputStates = mapOf("I0.0" to true, "I0.1" to true),
      deltaSeconds = 0.05f
    )
    assertFalse("Q0.0 must drop out when Stop NC input I0.1 is activated", outputs2["Q0.0"] == true)
    assertFalse(resultProg2.rungs[0].isRungActive)
  }

  @Test
  fun `test star delta scenario repository contains required training challenges`() {
    val scenarios = ScenarioRepository.scenarios
    assertTrue(scenarios.isNotEmpty())
    assertNotNull(scenarios.find { it.id == "star_delta" })
    assertNotNull(scenarios.find { it.id == "latching_contactor" })
    assertNotNull(scenarios.find { it.id == "smps_sensors" })
    assertNotNull(scenarios.find { it.id == "plc_conveyor" })
  }
}
